<!DOCTYPE html>

<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="style.css" />

</head>

<body>

    <div class="col-12">
        <div class="row mt-1 mb-1">

            <div class="offset-lg-1 col-12 col-lg-7 align-align-self-center mt-2">

                <?php

                session_start();

                if (isset($_SESSION["u"])) {
                    $data = $_SESSION["u"];
                    $mail = $data["email"];




                ?><img src="resource/logo.png" height="100px" alt="logo">
                    <span class="text-lg-start " style=" font-size: 20px;"><?php echo $data["fname"]; ?> <?php echo $data["lname"]; ?> Explore What Gamer's Shop Offers</span>

                <?php

                } else {
                ?>
                    <a href="index.php" class="text-decoration-none fw-bold">Sign In or Register</a>
                <?php
                }

                ?>



            </div>

            <div class="col-12 col-lg-2 offset-lg-2 align-self-center" style="text-align: center;">
                <div class="row">



                    <div class="col-12 col-lg-6 dropdown">




                        <button class="btn btn-dark mt-3 border border-1 dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="border-color: grey;">
                            My Settings
                        </button>
                        <ul class="dropdown-menu dropdown-menu-dark">
                            <?php



                            ?>

                            <?php

                            if (isset($_SESSION["u"])) {


                            ?>
                                <li><a class="dropdown-item" href="Home.php">Homepage</a></li>
                                <li><a class="dropdown-item" href="userProfile.php">My Profile</a></li>

                                <li><a class="dropdown-item" href="myProducts.php">My Products</a></li>

                                <li><a class="dropdown-item" href="watchlist.php">My Watchlist</a></li>
                                <li><a class="dropdown-item" href="cart.php">My Cart</a></li>
                                <li><a class="dropdown-item" href="Seller_Sales.php">My Sales</a></li>
                                <li><a class="dropdown-item" href="purchasingHistory.php">Purchase History</a></li>

                                <li><a class="dropdown-item btn" onclick="signout();">LogOut</a></li>

                            <?php

                            } ?>



                        </ul>
                    </div>





                    <!-- msg modal -->

                    <!--  -->

                </div>
            </div>

        </div>
    </div>


    <script src="script.js"></script>
</body>

</html>