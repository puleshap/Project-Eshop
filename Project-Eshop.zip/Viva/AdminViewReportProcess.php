<?php

include "connection.php";


$id = $_GET["e"];



        Database::iud("UPDATE `reports` SET `status`='2' WHERE `id`='" . $id . "'");
        echo ("success");

    


?>