<?php

require "connection.php";

?>

<link rel="stylesheet" href="bootstrap.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="style.css" />
<link rel="stylesheet" href="styles/Admin_User_Panel.css" />


<div class="col-12 bg-dark text-center">
    <label class="form-label text-primary fw-bold fs-1">S a l e s &nbsp; &nbsp; M a n a g e m e n t &nbsp; &nbsp; P a n e l</label>
</div>
<div class="container">
    <br>
    <div class="search-bar">

        <input type="text" id="searchUsers" placeholder="Search Product" class=" rounded rounded-3">
        <button id="searchButton " class=" rounded rounded-3 border border-3" onclick="SearchMProductPanel();">🔍</button>



    </div>
    <br>
    <div class="table-wrapper">
        <table id="userTable">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Product Name</th>
                    <th>Quantity</th>
                    <th>Registered Date</th>
                    <th>Price</th>
                    <th>Quantity</th>

                    <th>Status</th>
                    <th>Actions</th>

                </tr>
            </thead>
            <tbody id="tbody">
                <?php

                $query = "SELECT product.*, brand_name,category_name,model_name FROM `product`
INNER JOIN category ON product.category_id = category.id
INNER JOIN brand ON product.brand_has_model_id = brand.id
INNER JOIN brand_has_model ON product.brand_has_model_id = brand_has_model.model_id
INNER JOIN model ON brand_has_model.model_id = model.id ";



                $user_rs = Database::search($query);
                $user_num = $user_rs->num_rows;

                $selected_rs = Database::search($query);

                $selected_num = $selected_rs->num_rows;

                for ($x = 0; $x < $selected_num; $x++) {
                    $selected_data = $selected_rs->fetch_assoc();

$ct = $selected_data["category_name"];
$br = $selected_data["brand_name"];
$md = $selected_data["model_name"];
$rs = Database::search("SELECT COUNT(`product_id`) AS `value_occurence` FROM `invoice` 
                                WHERE  `product_id`  = '".$selected_data["id"]."' ");

$rs_data = $rs->fetch_assoc();
$count = $rs_data['value_occurence'];
                ?>

                    <tr>
                        <td><?php echo ($selected_data["id"]); ?></td>
                        <td><?php echo $selected_data["title"]; ?></td>
                        <td><?php
                            $image_rs = Database::search("SELECT * FROM `product_image` WHERE `product_id`='" . $selected_data["id"] . "'");
                            $image_num = $image_rs->num_rows;

                            if ($image_num == 0) {
                            ?>
                                <img src="resource/mobile_images/iphone_12.jpeg" style="height: 40px;margin-left: 80px;" />
                            <?php
                            } else {
                                $image_data = $image_rs->fetch_assoc();
                            ?>
                                <img src="<?php echo $image_data["img_path"]; ?>" style="height: 40px;margin-left: 80px;  width: 50px;" />
                            <?php
                            }
                            ?>
                        </td>
                        <td><?php echo $selected_data["date_time"]; ?></td>

                        <td>Rs. <?php echo $selected_data["price"]; ?> .00</td>
                        <td><?php echo $selected_data["qty"]; ?></td>

                        <?php
                        if ($selected_data["status_id"] == 1) {
                        ?>
                            <td class="status">Active</td>
                        <?php
                        } elseif ($selected_data["status_id"] == 2) {
                        ?>
                            <td class="" style="color: yellow;">Deactive</td>
                        <?php
                        } elseif ($selected_data["status_id"] == 3) {
                        ?>
                            <td class="status-red">Blocked</td>
                        <?php
                        }
                        ?>
                        <td class="actions">
                            <?php
                            if ($selected_data["status_id"] == 1 or $selected_data["status_id"] == 2) {
                            ?>
                                <button onclick="blockProduct('<?php echo $selected_data['id']; ?>');">🔒</button>
                            <?php
                            } else {
                            ?>
                                <button onclick="blockProduct('<?php echo $selected_data['id']; ?>');">🔑</button>
                            <?php
                            }
                            ?>
                          <button onclick="ProductModalview('<?php echo $ct; ?>', '<?php echo $br; ?>', '<?php echo $md; ?>', '<?php echo $count; ?>');">🧾</button>


                            <a  href='<?php echo "singleProductView.php?id=" . ($selected_data["id"]); ?>'><button>📄</button></a>

                        </td>


                    </tr>

                <?php

                }
                ?>

            </tbody>
        </table>
    </div>
</div>
<div class="modal" tabindex="-1" id="userMsgModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" >Addition Details of Selected Product</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <div class="row g-3">

                    <div class="col-12 mt-2">
                        <div class="row">

                        </div>
                    </div>

                    <div class="col-12">
                    <h5 class="modal-title" id="ct">Add new Category</h5>
                        <br>
                        <h5 class="modal-title" id="br">Add new Category</h5>
                        <br>
                        <h5 class="modal-title" id="md">Add new Category</h5>
                        <br>
                        <h5 class="modal-title" id="cnt">Add new Category</h5>
                    </div>
                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
</div>

<script src="bootstrap.bundle.js"></script>
<script src="script.js"></script>
<script src="AdminScript.js"></script>