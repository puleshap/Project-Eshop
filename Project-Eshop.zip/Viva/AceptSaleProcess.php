<?php

include "connection.php";

if(isset($_GET["id"])){

    $order_id = $_GET["id"];

    Database::iud("UPDATE `sales` SET `status`='2' WHERE `order_id`='".$order_id."'");
    echo ("success");

}

?>