<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Add Product | GamerShop</title>
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="styles/add_product.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />

    <link rel="icon" href="resource/logo.png" />

</head>



<body style="  background: linear-gradient(to bottom, #002d5b, #000000); color: #ffffff;">
    <div class="container-fluid">
        <div class="row gy-3">
            <?php

            include "header.php";

            if (isset($_SESSION["u"])) {

                include "connection.php";

            ?>
                <hr style=" height: 2px; background-color: #ffffff; ">
                <div class="col-12">
                    <div class="row">
                        <div class="col-12 bg-success">
                            <label class="form-label fw-bold" style="font-size: 30px;">Notice...</label><br />
                            <label class="form-label fs-5">
                                We are taking 7% of the product from price from every
                                product as a service charge. <br>
                                The money will be deposited to your paypal account after the deduction of the service charge.
                            </label>
                        </div>
<hr>
                        <div class="col-12 text-center">
                            <br>
                            <h2 class="h2 text-info fw-bold">Add New Product</h2>
                        </div>
<hr>
                        <div class="col-12">
                            <div class="row">

                                <div class="col-12 col-lg-4 border-end border-success">
                                    <div class="row">

                                        <div class="col-12">
                                            <label class="form-label fw-bold" style="font-size: 20px;">Select Product Category</label>
                                        </div>

                                        <div class="col-12">
                                            <select class="form-select text-center text-white" style="background-color:#002d5b ;" id="category" onchange="load_brand();">
                                                <option value="0">Select Category</option>
                                                <?php
                                                $category_rs = Database::search("SELECT * FROM `category`");
                                                $category_num = $category_rs->num_rows;

                                                for ($x = 0; $x < $category_num; $x++) {
                                                    $category_data = $category_rs->fetch_assoc();
                                                ?>
                                                    <option value="<?php echo $category_data["id"]; ?>">
                                                        <?php echo $category_data["category_name"]; ?>
                                                    </option>
                                                <?php
                                                }
                                                ?>
                                            </select>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-12 col-lg-4 border-end border-success">
                                    <div class="row">

                                        <div class="col-12">
                                            <label class="form-label fw-bold" style="font-size: 20px;">Select Product Brand</label>
                                        </div>

                                        <div class="col-12">
                                            <select class="form-select text-center text-white" style="background-color:#002d5b ;" id="brand" onchange="load_model();">
                                                <option value="0">Select Brand</option>

                                            </select>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-12 col-lg-4 border-end border-success">
                                    <div class="row">

                                        <div class="col-12">
                                            <label class="form-label fw-bold" style="font-size: 20px;">Select Product Model</label>
                                        </div>

                                        <div class="col-12">
                                            <select class="form-select text-center text-white" style="background-color:#002d5b ;" id="model">
                                                <option value="0">Select Model</option>

                                            </select>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-12">
                                    <hr style=" height: 2px; background-color: #ffffff; ">
                                </div>

                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12">
                                            <label class="form-label fw-bold" style="font-size: 20px;">
                                                Add a Title to your Product
                                            </label>
                                        </div>
                                        <div class="offset-0 offset-lg-2 col-12 col-lg-8">
                                            <input type="text" class="form-control text-white" style="background-color:#002d5b ;" id="title" />
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <hr style=" height: 2px; background-color: #ffffff; ">
                                </div>

                                <div class="col-12">
                                    <div class="row">

                                        <div class="col-12 col-lg-4 border-end border-success">
                                            <div class="row">
                                                <div class="col-12">
                                                    <label class="form-label fw-bold" style="font-size: 20px;">Select Product Condition</label>
                                                </div>
                                                <div class="col-12">
                                                    <div class="form-check form-check-inline mx-5">
                                                        <input class="form-check-input" type="radio" name="c" id="b" checked />
                                                        <label class="form-check-label fw-bold" for="b">Brandnew</label>
                                                    </div>
                                                    <div class="form-check form-check-inline">
                                                        <input class="form-check-input" type="radio" name="c" id="u" />
                                                        <label class="form-check-label fw-bold" for="u">Used</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-12 col-lg-4 border-end border-success">

                                        </div>

                                        <div class="col-12 col-lg-4">
                                            <div class="row">
                                                <div class="col-12">
                                                    <label class="form-label fw-bold" style="font-size: 20px;">Add Product Quantity</label>
                                                </div>
                                                <div class="col-12">
                                                    <input type="number" class="form-control text-white" style="background-color:#002d5b ;" value="0" min="0" id="qty" />
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-12">
                                    <hr style=" height: 2px; background-color: #ffffff; ">
                                </div>

                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-3">
                                            <div class="row">

                                            </div>
                                        </div>

                                        <div class="col-6 ">
                                            <div class="row">
                                                <div class="col-12">
                                                    <label class="form-label fw-bold " style="font-size: 20px;">Cost Per Item</label>
                                                </div>
                                                <div class="offset-0 offset-lg-2 col-12 col-lg-8 ">
                                                    <div class="input-group mb-2 mt-2  ">
                                                        <span class="input-group-text text-white" style="background-color:#002d5b ;">Rs.</span>
                                                        <input type="text" class="form-control text-white" style="background-color:#002d5b ;" id="cost" />
                                                        <span class="input-group-text text-white" style="background-color:#002d5b ;">.00</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                    </div>
                                </div>

                                <div class="col-12">
                                    <hr style=" height: 2px; background-color: #ffffff; ">
                                </div>

                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12">
                                            <label class="form-label fw-bold" style="font-size: 20px;">Delivery Cost</label>
                                        </div>
                                        <div class="col-12 col-lg-6 border-end border-success">
                                            <div class="row">
                                                <div class="col-12 offset-lg-1 col-lg-3">
                                                    <label class="form-label">Delivery cost Within Colombo</label>
                                                </div>
                                                <div class="col-12 col-lg-8">
                                                    <div class="input-group mb-2 mt-2">
                                                        <span class="input-group-text text-white" style="background-color:#002d5b ;">Rs.</span>
                                                        <input type="text" class="form-control text-white" style="background-color:#002d5b ;" id="dwc" />
                                                        <span class="input-group-text text-white" style="background-color:#002d5b ;">.00</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-lg-6">
                                            <div class="row">
                                                <div class="col-12 offset-lg-1 col-lg-3">
                                                    <label class="form-label">Delivery cost out of Colombo</label>
                                                </div>
                                                <div class="col-12 col-lg-8">
                                                    <div class="input-group mb-2 mt-2">
                                                        <span class="input-group-text text-white" style="background-color:#002d5b ;">Rs.</span>
                                                        <input type="text" class="form-control text-white" style="background-color:#002d5b ;" id="doc" />
                                                        <span class="input-group-text text-white" style="background-color:#002d5b ;">.00</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <hr class="border-success" />
                                </div>

                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12">
                                            <label class="form-label fw-bold" style="font-size: 20px;">Product Description</label>
                                        </div>
                                        <div class="col-12">
                                            <textarea cols="30" rows="15" class="form-control text-white" style="background-color:#002d5b ;" id="desc"></textarea>
                                        </div>
                                    </div>
                                </div>


                                <div class="col-12">
                                    <hr style=" height: 2px; background-color: #ffffff; ">
                                </div>

                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12">
                                            <label class="form-label fw-bold" style="font-size: 20px;">Add Product Images &nbsp; (Maximum of 7 images)</label>
                                        </div>
                                        <div class=" col-12 col-lg-12">
                                            <div class="row">
                                                <div class="image-preview-container" id="imagePreviewContainer">
                                                    <!-- Image previews will appear here -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="offset-lg-3 col-12 col-lg-6 d-grid mt-3">
                                            <input type="file" class="d-none" id="imageInput" onchange="handleImageChange()" multiple>
                                            <label for="imageInput" class="col-12 btn btn-info fw-bold">Upload Images</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <hr class="border-success" />
                                </div>



                                <div class="offset-lg-4 col-12 col-lg-4 d-grid mt-3 mb-3">
                                    <button class="btn btn-success" onclick="addProduct();">Save Product</button>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>

            <?php

            } else {
                header("Location: home.php");
            }

            ?>

            <?php include "footer.php"; ?>
        </div>
    </div>

    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>


</html>