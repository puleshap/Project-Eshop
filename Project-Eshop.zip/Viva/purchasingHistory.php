<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Purchasing History | GamerShop</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="styles/Admin_User_Panel.css" />

    <link rel="icon" href="resource/logo.png" />
</head>


<body style="  background: linear-gradient(to bottom, #002d5b, #000000);color: #ffffff;">

    <div class="container-fluid">
        <div class="row">

            <?php include "header.php";

            include "connection.php";

            if (isset($_SESSION["u"])) {
                $mail = $_SESSION["u"]["email"];

                $invoice_rs = Database::search("SELECT * FROM `invoice` WHERE `user_email`='" . $mail . "'");
                $invoice_num = $invoice_rs->num_rows;

            ?>
                <hr>
                <div class="col-12 text-center mb-3">
                    <span class="fs-1 fw-bold text-info">Purchasing History</span>
                </div>
                <ul class="nav nav-tabs bg-black" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Single Purchases</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Cart Purchases</button>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <?php

                        if ($invoice_num == 0) {
                        ?>
                            <!-- empty view -->
                            <div class="col-12 text-center " style="height: 100px;">
                                <span class="fs-1 fw-bold text-white-50 d-block" style="margin-top: 200px;">
                                    You have not purchased any item yet...
                                </span>
                            </div>
                            <!-- empty view -->
                        <?php
                        } else {
                        ?>
                            <!-- Have Product -->
                            <div class="container transaction-history"><br>
                                <h2 class="text-center">Single Product Transaction History</h2>
                                <hr> <?php
                                        $rs = Database::search("SELECT * FROM `invoice` WHERE `user_email`='$mail' AND `status`='0'");
                                        $num = $rs->num_rows;
                                        if ($num == 0) {
                                        ?>
                                    <div class="col-12 text-center " style="height: 100px;">
                                        <span class="fs-1 fw-bold text-white-50 d-block" style="margin-top: 200px;">
                                            You have not purchased any item yet...
                                        </span>
                                    </div>
                                <?php } else { ?>
                                    <div class=" table table-wrapper " style="max-height: 430px;">

                                        <table>
                                            <thead>
                                                <tr class="text-dark bg-secondary">
                                                    <th class="text-dark bg-secondary">Order ID</th>
                                                    <th class="bg-secondary">Item</th>
                                                    <th class="bg-secondary">Seller</th>
                                                    <th class="bg-secondary">Transaction Time</th>
                                                    <th class="bg-secondary">qty</th>

                                                    <th class="bg-secondary">Total</th>
                                                    <th class="bg-secondary">Actions</th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $rs = Database::search("SELECT * FROM `invoice` WHERE `user_email`='$mail' AND `status`='0'");
                                                $num = $rs->num_rows;
                                                for ($x = 0; $x < $num; $x++) {
                                                    $data = $rs->fetch_assoc();
                                                    $id = $data['order_id'];


                                                    $details_rs = Database::search("SELECT * FROM `product` INNER JOIN `product_image` ON 
                                         product.id=product_image.product_id INNER JOIN `user` ON product.user_email=user.email 
                                                          WHERE `id`='" . $data["product_id"] . "'");

                                                    $product_data = $details_rs->fetch_assoc();

                                                ?>
                                                    <tr>
                                                        <td class="text-white"><?php echo ($id) ?></td>
                                                        <td class="text-white "><img src="<?php echo $product_data["img_path"]; ?>" class="img-thumbnail rounded-start mt-3 mx-3 " style="width: 50px;" />
                                                            Title : <?php echo ($product_data['title']) ?>
                                                            <a href='<?php echo "invoice.php?id=" . $id; ?>'> <button class="btn btn-outline-info mx-5 "> View Receipt</button></a>
                                                        </td>
                                                        <td class="text-white text-center" style="max-width: 200px;"><?php echo $product_data["fname"] . " " . $product_data["lname"]; ?></td>
                                                        <td class="text-danger"><?php echo ($data['date']) ?></td>
                                                        <td class="text-center text-white" style="max-width:100px;"><?php echo ($data['qty']) ?></td>
                                                        <td style="max-width: 250px;" class="text-white">Rs.<?php echo ($data['total']) ?>.00</td>
                                                        <td style="max-width: 350px;">
                                                            <a href='<?php echo "singleproductview.php?id=" . $product_data['id']; ?>'> <button class="btn btn-outline-primary "> Product</button></a>
                                                            <button class="btn btn-outline-success" onclick="addFeedback(<?php echo $product_data['id']; ?>);">Feedback</button>
                                                            <button class="btn btn-outline-warning" onclick="report(<?php echo $product_data['id']; ?>);">Report</button>
                                                            <button class="btn btn-outline-danger" onclick="deleteFeedback(<?php echo $data['invoice_id']; ?>);">Delete</button>

                                                        </td>
                                                    </tr>
                                            <?php
                                                }
                                            }
                                            ?>

                                            </tbody>
                                        </table>
                                    </div>
                            </div>
                            <!-- Have Product -->
                    <?php
                        }
                    }

                    ?>
                    </div>
                </div>
                <div class="tab-pane fade hidden" id="profile" role="tabpanel" aria-labelledby="home-tab">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <br><?php
                            $invoice_rs = Database::search("SELECT * FROM `invoice_multiple` WHERE `user_email`='$mail'  ");
                            $invoice_num = $invoice_rs->num_rows;
                            if ($invoice_num == 0) {
                            ?>
                            <!-- empty view -->
                            <div class="col-12 text-center " style="height: 100px;">
                                <span class="fs-1 fw-bold text-white-50 d-block" style="margin-top: 200px;">
                                    You have not purchased any item yet...
                                </span>
                            </div>
                            <!-- empty view -->
                        <?php
                            } else {
                        ?>
                            <!-- Have Product -->
                            <div class="container transaction-history mb-5">
                                <h2 class="text-center ">Cart Item Transaction History</h2>
                                <br>
                                <table class="table  table-wrapper table-bordered">
                                    <thead class="text-white">
                                        <tr>
                                            <th>Order ID</th>
                                            <th>Products Purchased</th>
                                            <th>Transaction Time</th>
                                            <th>Number of Items</th>
                                            <th>Shipping Cost</th>
                                            <th>Total</th>
                                            <th>Actions</th>

                                        </tr>
                                    </thead>
                                    <tbody class="text-white">
                                        <?php
                                        $rs = Database::search("SELECT * FROM `invoice_multiple` WHERE `user_email`='$mail' AND `status`='0'");
                                        $num = $rs->num_rows;
                                        for ($x = 0; $x < $num; $x++) {
                                            $data = $rs->fetch_assoc();
                                            $id = $data['order_id'];
                                        ?>
                                            <tr>
                                                <td class="text-white"><?php echo ($id) ?></td>
                                                <td class="text-white"><?php echo ($data['product_titles']) ?></td>
                                                <td class="text-danger"><?php echo ($data['date']) ?></td>
                                                <td class="text-center"><?php echo ($data['qty']) ?></td>
                                                <td>RS.<?php echo ($data['shipping']) ?>.00</td>
                                                <td>Rs.<?php echo ($data['total']) ?></td>
                                                <td>
                                                    <a href='<?php echo "invoicecart.php?id=" . $id; ?>'> <button class="btn btn-outline-info"> Receipt</button></a> &nbsp;
                                                    <button class="btn btn-outline-danger" onclick="deleteMFeedback('<?php echo $data['order_id']; ?>');">Delete</button>
                                                </td>
                                            </tr>
                                        <?php
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                            <!-- Have Product -->
                        <?php
                            }


                        ?>
                    </div>
                </div>

                <!-- model -->
                <div class="modal " tabindex="-1" id="feedbackmodal">
                    <div class="modal-dialog ">
                        <div class="modal-content bg-dark">
                            <div class="modal-header">
                                <h5 class="modal-title fw-bold">Add New Feedback</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="row">
                                                <div class="col-">
                                                    <label class="fs-3">Product ID : </label>
                                                    <label class="fs-3" id="prod"></label>
                                                    <br>
                                                    <br>
                                                </div>

                                            </div>

                                            <div class="row">


                                                <div class="col-3">
                                                    <label class="form-label fw-bold">Type</label>
                                                </div>
                                                <div class="col-3">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="type" id="type1" />
                                                        <label class="form-check-label text-success fw-bold" for="type1">
                                                            Positive
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-3">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="type" id="type2" checked />
                                                        <label class="form-check-label text-warning fw-bold" for="type2">
                                                            Neutral
                                                        </label>
                                                    </div>
                                                </div>
                                                <div class="col-3">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="radio" name="type" id="type3" />
                                                        <label class="form-check-label text-danger fw-bold" for="type3">
                                                            Negative
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="row visually-hidden">
                                                <div class="col-3">
                                                    <label class="form-label fw-bold">User's Email</label>
                                                </div>
                                                <div class="col-9">
                                                    <input type="text" class="form-control text-white" style="background-color:#002d5b ;" disabled id="mail" value="<?php echo $mail; ?>" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 mt-2">
                                            <div class="row">
                                                <div class="col-3">
                                                    <label class="form-label fw-bold">Feedback</label>
                                                </div>
                                                <div class="col-9">
                                                    <textarea class="form-control text-white" style="background-color:#002d5b ;" cols="50" rows="8" id="feed"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-outline-success" onclick="saveFeedback();">Save Feedback</button>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal " tabindex="-1" id="report">
                    <div class="modal-dialog ">
                        <div class="modal-content bg-dark">
                            <div class="modal-header">
                                <h5 class="modal-title fw-bold">Report Product to Admin</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12">

                                            <div class="row">
                                                <div class="col-">
                                                    <label class="fs-3">Product ID : </label>
                                                    <label class="fs-3" id="prodd"></label>
                                                    <br>
                                                    <br>
                                                </div>

                                            </div>

                                        </div>
                                        <div class="col-12">
                                            <div class="row ">
                                                <div class="col-3">
                                                    <label class="form-label fw-bold">User's Email</label>
                                                </div>
                                                <div class="col-9">
                                                    <input type="text" class="form-control text-white" style="background-color:#002d5b ;" disabled id="mail" value="<?php echo $mail; ?>" />
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 mt-2">
                                            <div class="row">
                                                <div class="col-3">
                                                    <label class="form-label fw-bold">Report Description</label>
                                                </div>
                                                <div class="col-9">
                                                    <textarea class="form-control text-white" style="background-color:#002d5b ;" cols="50" rows="8" id="rep"></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="button" class="btn btn-outline-success" onclick="savereport();">Submit Report</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- model -->
                <?php include "footer.php"; ?>

        </div>
    </div>

    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>




</html>