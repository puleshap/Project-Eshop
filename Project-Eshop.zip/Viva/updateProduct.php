<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Update Product | GamerShop</title>
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="styles/add_product.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />

    <link rel="icon" href="resource/logo.png" />

</head>
<?php if (isset($_COOKIE["color"])) {

?>

    <body style="  background: linear-gradient(to bottom, #002d5b, #000000);color: #ffffff;">

        <div class="container-fluid">
            <div class="row gy-3">

                <?php include "header.php";

                if (isset($_SESSION["u"])) {
                    if (isset($_SESSION["p"])) {

                        include "connection.php";
                        $product = $_SESSION["p"];

                ?>

                        <div class="col-12">
                            <div class="row">

                                <div class="col-12 bg-success">
                                    <label class="form-label fw-bold" style="font-size: 30px;">Notice...</label><br />
                                    <label class="form-label fs-5">
                                        We are taking 7% of the product from price from every
                                        product as a service charge. <br>
                                        The money will be deposited to your paypal account after the deduction of the service charge.
                                    </label>
                                </div>
                                <hr>
                                <div class="col-12 text-center">
                                    <h2 class="h2 text-info fw-bold">Update Product</h2>
                                </div>
                                <hr>
                                <div class="col-12">
                                    <div class="row">

                                        <div class="col-12 col-lg-4 border-end border-success">
                                            <div class="row">

                                                <div class="col-12">
                                                    <label class="form-label fw-bold" style="font-size: 20px;">Product Category</label>
                                                </div>

                                                <div class="col-12">
                                                    <select class="form-select text-center  text-white" style="background-color: #002d5b;" disabled>
                                                        <?php
                                                        $category_rs = Database::search("SELECT * FROM `category` WHERE `id`='" . $product["category_id"] . "'");
                                                        $category_data = $category_rs->fetch_assoc();
                                                        ?>
                                                        <option><?php echo $category_data["category_name"]; ?></option>
                                                    </select>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="col-12 col-lg-4 border-end border-success">
                                            <div class="row">

                                                <div class="col-12">
                                                    <label class="form-label fw-bold" style="font-size: 20px;">Product Brand</label>
                                                </div>

                                                <div class="col-12">
                                                    <select class="form-select text-center  text-white" style="background-color: #002d5b;" disabled>
                                                        <?php
                                                        $brand_rs = Database::search("SELECT * FROM `brand` WHERE `id` IN 
                                    (SELECT `brand_id` FROM `brand_has_model` WHERE `id`='" . $product["brand_has_model_id"] . "')");
                                                        $brand_data = $brand_rs->fetch_assoc();
                                                        ?>
                                                        <option><?php echo $brand_data["brand_name"]; ?></option>
                                                    </select>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="col-12 col-lg-4 border-end border-success">
                                            <div class="row">

                                                <div class="col-12">
                                                    <label class="form-label fw-bold " style="font-size: 20px;">Product Model</label>
                                                </div>

                                                <div class="col-12">
                                                    <select class="form-select text-center  text-white" style="background-color: #002d5b;" disabled>
                                                        <?php
                                                        $model_rs = Database::search("SELECT * FROM `model` WHERE `id` IN 
                                    (SELECT `model_id` FROM `brand_has_model` WHERE `id`='" . $product["brand_has_model_id"] . "')");
                                                        $model_data = $model_rs->fetch_assoc();
                                                        ?>
                                                        <option><?php echo $model_data["model_name"]; ?></option>
                                                    </select>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <hr class="border-success" />
                                        </div>

                                        <div class="col-12">
                                            <div class="row">
                                                <div class="col-12">
                                                    <label class="form-label fw-bold" sstyle="background-color: #002d5b; font-size: 20px;">
                                                        Product Title
                                                    </label>
                                                </div>
                                                <div class="offset-0 offset-lg-2 col-12 col-lg-8">
                                                    <input type="text" class="form-control  text-white" style="background-color: #002d5b;" value="<?php echo $product["title"]; ?>" id="t" />
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <hr class="border-success" />
                                        </div>

                                        <div class="col-12">
                                            <div class="row">

                                                <div class="col-12 col-lg-4 border-end border-success">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="form-label fw-bold" style="font-size: 20px;">Product Condition</label>
                                                        </div>
                                                        <?php

                                                        if ($product["condition_id"] == 1) {
                                                        ?>
                                                            <div class="col-12">
                                                                <div class="form-check form-check-inline mx-5  text-white">
                                                                    <input class="form-check-input" type="radio" id="b" name="c" checked disabled />
                                                                    <label class="form-check-label fw-bold text-white" for="b">Brandnew</label>
                                                                </div>
                                                                <div class="form-check form-check-inline text-white">
                                                                    <input class="form-check-input" type="radio" id="u" name="c" disabled />
                                                                    <label class="form-check-label fw-bold  text-white" for="u">Used</label>
                                                                </div>
                                                            </div>
                                                        <?php
                                                        } else {
                                                        ?>
                                                            <div class="col-12">
                                                                <div class="form-check form-check-inline mx-5  text-white">
                                                                    <input class="form-check-input  text-white" type="radio" id="b" name="c" disabled />
                                                                    <label class="form-check-label fw-bold text-white" for="b">Brandnew</label>
                                                                </div>
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input bg-dark text-white" type="radio" id="u" name="c" checked disabled />
                                                                    <label class="form-check-label fw-bold bg-dark text-white" for="u">Used</label>
                                                                </div>
                                                            </div>
                                                        <?php
                                                        }

                                                        ?>

                                                    </div>
                                                </div>

                                                <div class="col-12 col-lg-4 border-end border-success">
                                                    <div class="row">




                                                    </div>
                                                </div>

                                                <div class="col-12 col-lg-4">
                                                    <div class="row">
                                                        <div class="col-12">
                                                            <label class="form-label fw-bold" style="font-size: 20px;">Product Quantity</label>
                                                        </div>
                                                        <div class="col-12">
                                                            <input type="number" class="form-control  text-white" style="background-color: #002d5b;" min="0" value="<?php echo $product["qty"]; ?>" id="q" />
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <hr class="border-success" />
                                        </div>

                                        <div class="col-6 border-end border-success">
                                            <div class="row">
                                                <div class="col-12 ">
                                                    <label class="form-label fw-bold " style="font-size: 20px;">Current Cost Per Item</label>
                                                </div>
                                                <div class="offset-0 offset-lg-2 col-12 col-lg-8 ">
                                                    <div class="input-group mb-2 mt-2  ">
                                                        <span class="input-group-text  text-white" style="background-color: #002d5b;">Rs.</span>
                                                        <input type="text" class="form-control text-white" style="background-color: #002d5b;" disabled value="<?php echo $product["price"]; ?>" />
                                                        <span class="input-group-text  text-white" style="background-color: #002d5b;">.00</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-6 ">
                                            <div class="row">
                                                <div class="col-12">
                                                    <label class="form-label fw-bold " style="font-size: 20px;">New Cost Per Item</label>
                                                </div>
                                                <div class="offset-0 offset-lg-2 col-12 col-lg-8 ">
                                                    <div class="input-group mb-2 mt-2  ">
                                                        <span class="input-group-text  text-white" style="background-color: #002d5b;">Rs.</span>
                                                        <input type="text" class="form-control text-white" style="background-color: #002d5b;" id="new_value" />
                                                        <span class="input-group-text  text-white" style="background-color: #002d5b;">.00</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>



                                    </div>
                                </div>

                                <div class="col-12">
                                    <hr class="border-success" />
                                </div>

                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12">
                                            <label class="form-label fw-bold " style="font-size: 20px;">Delivery Cost</label>
                                        </div>
                                        <div class="col-12 col-lg-6 border-end border-success">
                                            <div class="row">
                                                <div class="col-12 offset-lg-1 col-lg-3">
                                                    <label class="form-label  text-white">Delivery cost Within Colombo</label>
                                                </div>
                                                <div class="col-12 col-lg-8">
                                                    <div class="input-group mb-2 mt-2">
                                                        <span class="input-group-text  text-white" style="background-color: #002d5b;">Rs.</span>
                                                        <input type="text" class="form-control  text-white" style="background-color: #002d5b;" value="<?php echo $product["delivery_fee_colombo"]; ?>" id="dwc" />
                                                        <span class="input-group-text  text-white" style="background-color: #002d5b;">.00</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 col-lg-6">
                                            <div class="row">
                                                <div class="col-12 offset-lg-1 col-lg-3">
                                                    <label class="form-label text-white">Delivery cost out of Colombo</label>
                                                </div>
                                                <div class="col-12 col-lg-8">
                                                    <div class="input-group mb-2 mt-2">
                                                        <span class="input-group-text text-white" style="background-color: #002d5b;">Rs.</span>
                                                        <input type="text" class="form-control  text-white" style="background-color: #002d5b;" value="<?php echo $product["delivery_fee_other"]; ?>" id="doc" />
                                                        <span class="input-group-text  text-white" style="background-color: #002d5b;">.00</span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <hr class="border-success" />
                                </div>

                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12">
                                            <label class="form-label fw-bold" style="font-size: 20px;">Product Description</label>
                                        </div>
                                        <div class="col-12">
                                            <textarea cols="30" rows="15" class="form-control  text-white" style="background-color: #002d5b;" id="d"><?php echo $product["description"]; ?></textarea>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <hr class="border-success" />
                                </div>

                                <div class="col-12">
                                    <div class="row">
                                        <div class="col-12">
                                            <label class="form-label fw-bold" style="font-size: 20px;">Add Product Images &nbsp; (Maximum of 7 images) (Adding Images Will replace the current images)</label>
                                        </div>
                                        <div class=" col-12 col-lg-12">
                                            <div class="row">
                                                <div class="image-preview-container" id="imagePreviewContainer">
                                                    <!-- Image previews will appear here -->
                                                </div>
                                            </div>
                                        </div>
                                        <div class="offset-lg-3 col-12 col-lg-6 d-grid mt-3">
                                            <input type="file" class="d-none" id="imageInput" onchange="handleImageChange()" multiple>
                                            <label for="imageInput" class="col-12 btn  btn-info fw-bold ">Upload Images</label>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <hr class="border-success" />
                                </div>

                                <div class="offset-lg-4 col-12 col-lg-4 d-grid mt-3 mb-3">
                                    <button class="btn btn-success" onclick="updateProduct();">Update Product</button>
                                </div>

                            </div>
                        </div>

            </div>
        </div>

    <?php
                    } else {
    ?>
        <script>
            alert("Please select a product to update.");
            window.location = "myProducts.php";
        </script>
    <?php
                    }
                } else {
    ?>
    <script>
        alert("You have to signin to the system for access this function.");
        window.location = "home.php";
    </script>
<?php
                }

                include "footer.php";
?>
</div>
</div>

<script src="bootstrap.bundle.js"></script>
<script src="script.js"></script>
    </body>

<?php
} ?>



</html>