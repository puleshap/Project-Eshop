<?php

include "connection.php";
session_start();
$search_txt = $_POST["t"];
$category = $_POST["cat"];
$brand = $_POST["b"];
$model = $_POST["m"];
$condition = $_POST["con"];
$price_from = $_POST["pf"];
$price_to = $_POST["pt"];
$sort = $_POST["s"];

$query = "SELECT * FROM `product`";
$status = 0;

if ($sort == 0) {
    if (!empty($search_txt)) {
        $query .= " WHERE `title` LIKE '%" . $search_txt . "%'";
        $status = 1;
    }

    if ($category != 0) {
        $query .= $status == 0 ? " WHERE `category_id`='" . $category . "'" : " AND `category_id`='" . $category . "'";
        $status = 1;
    }

    $pid = 0;
    if ($brand != 0 && $model == 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `brand_id`='" . $brand . "'");
        while ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $pid = $brand_has_model_data["id"];
        }
        $query .= $status == 0 ? " WHERE `brand_has_model_id`='" . $pid . "'" : " AND `brand_has_model_id`='" . $pid . "'";
        $status = 1;
    }

    if ($brand == 0 && $model != 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `model_id`='" . $model . "'");
        while ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $pid = $brand_has_model_data["id"];
        }
        $query .= $status == 0 ? " WHERE `brand_has_model_id`='" . $pid . "'" : " AND `brand_has_model_id`='" . $pid . "'";
        $status = 1;
    }

    if ($brand != 0 && $model != 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `brand_id`='" . $brand . "' AND `model_id`='" . $model . "'");
        while ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $pid = $brand_has_model_data["id"];
        }
        $query .= $status == 0 ? " WHERE `brand_has_model_id`='" . $pid . "'" : " AND `brand_has_model_id`='" . $pid . "'";
        $status = 1;
    }

    if ($condition != 0) {
        $query .= $status == 0 ? " WHERE `condition_id`='" . $condition . "'" : " AND `condition_id`='" . $condition . "'";
        $status = 1;
    }

    if (!empty($price_from) && !empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` BETWEEN '" . $price_from . "' AND '" . $price_to . "'" : " AND `price` BETWEEN '" . $price_from . "' AND '" . $price_to . "'";
        $status = 1;
    } else {
        if (!empty($price_from)) {
            $query .= $status == 0 ? " WHERE `price` >= '" . $price_from . "'" : " AND `price` >= '" . $price_from . "'";
            $status = 1;
        }

        if (!empty($price_to)) {
            $query .= $status == 0 ? " WHERE `price` <= '" . $price_to . "'" : " AND `price` <= '" . $price_to . "'";
            $status = 1;
        }
    }
} else if ($sort == 2) {
    if (!empty($search_txt)) {
        $query .= " WHERE `title` LIKE '%" . $search_txt . "%'";
        $status = 1;
    }

    if ($category != 0) {
        $query .= $status == 0 ? " WHERE `category_id`='" . $category . "'" : " AND `category_id`='" . $category . "'";
        $status = 1;
    }

    $pid = 0;
    if ($brand != 0 && $model == 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `brand_id`='" . $brand . "'");
        $brand_has_model_ids = [];
        while ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $brand_has_model_ids[] = $brand_has_model_data["id"];
        }
        if (!empty($brand_has_model_ids)) {
            $query .= $status == 0 ? " WHERE `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")" : " AND `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")";
            $status = 1;
        }
    }

    if ($brand == 0 && $model != 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `model_id`='" . $model . "'");
        $brand_has_model_ids = [];
        while ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $brand_has_model_ids[] = $brand_has_model_data["id"];
        }
        if (!empty($brand_has_model_ids)) {
            $query .= $status == 0 ? " WHERE `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")" : " AND `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")";
            $status = 1;
        }
    }

    if ($brand != 0 && $model != 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `brand_id`='" . $brand . "' AND `model_id`='" . $model . "'");
        if ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $pid = $brand_has_model_data["id"];
            $query .= $status == 0 ? " WHERE `brand_has_model_id`='" . $pid . "'" : " AND `brand_has_model_id`='" . $pid . "'";
            $status = 1;
        }
    }

    if ($condition != 0) {
        $query .= $status == 0 ? " WHERE `condition_id`='" . $condition . "'" : " AND `condition_id`='" . $condition . "'";
        $status = 1;
    }

    if (!empty($price_from) && empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` >= '" . $price_from . "'" : " AND `price` >= '" . $price_from . "'";
        $status = 1;
    }

    if (empty($price_from) && !empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` <= '" . $price_to . "'" : " AND `price` <= '" . $price_to . "'";
        $status = 1;
    }

    if (!empty($price_from) && !empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` BETWEEN '" . $price_from . "' AND '" . $price_to . "'" : " AND `price` BETWEEN '" . $price_from . "' AND '" . $price_to . "'";
        $status = 1;
    }

    $query .= " ORDER BY `price` ASC";
} else if ($sort == 1) {
    if (!empty($search_txt)) {
        $query .= " WHERE `title` LIKE '%" . $search_txt . "%'";
        $status = 1;
    }

    if ($category != 0) {
        $query .= $status == 0 ? " WHERE `category_id`='" . $category . "'" : " AND `category_id`='" . $category . "'";
        $status = 1;
    }

    $pid = 0;
    if ($brand != 0 && $model == 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `brand_id`='" . $brand . "'");
        $brand_has_model_ids = [];
        while ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $brand_has_model_ids[] = $brand_has_model_data["id"];
        }
        if (!empty($brand_has_model_ids)) {
            $query .= $status == 0 ? " WHERE `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")" : " AND `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")";
            $status = 1;
        }
    }

    if ($brand == 0 && $model != 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `model_id`='" . $model . "'");
        $brand_has_model_ids = [];
        while ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $brand_has_model_ids[] = $brand_has_model_data["id"];
        }
        if (!empty($brand_has_model_ids)) {
            $query .= $status == 0 ? " WHERE `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")" : " AND `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")";
            $status = 1;
        }
    }

    if ($brand != 0 && $model != 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `brand_id`='" . $brand . "' AND `model_id`='" . $model . "'");
        if ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $pid = $brand_has_model_data["id"];
            $query .= $status == 0 ? " WHERE `brand_has_model_id`='" . $pid . "'" : " AND `brand_has_model_id`='" . $pid . "'";
            $status = 1;
        }
    }

    if ($condition != 0) {
        $query .= $status == 0 ? " WHERE `condition_id`='" . $condition . "'" : " AND `condition_id`='" . $condition . "'";
        $status = 1;
    }

    if (!empty($price_from) && empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` >= '" . $price_from . "'" : " AND `price` >= '" . $price_from . "'";
        $status = 1;
    }

    if (empty($price_from) && !empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` <= '" . $price_to . "'" : " AND `price` <= '" . $price_to . "'";
        $status = 1;
    }

    if (!empty($price_from) && !empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` BETWEEN '" . $price_from . "' AND '" . $price_to . "'" : " AND `price` BETWEEN '" . $price_from . "' AND '" . $price_to . "'";
        $status = 1;
    }

    $query .= " ORDER BY `price` DESC";
} else if ($sort == 3) {
    if (!empty($search_txt)) {
        $query .= " WHERE `title` LIKE '%" . $search_txt . "%'";
        $status = 1;
    }

    if ($category != 0) {
        $query .= $status == 0 ? " WHERE `category_id`='" . $category . "'" : " AND `category_id`='" . $category . "'";
        $status = 1;
    }

    $pid = 0;
    if ($brand != 0 && $model == 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `brand_id`='" . $brand . "'");
        $brand_has_model_ids = [];
        while ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $brand_has_model_ids[] = $brand_has_model_data["id"];
        }
        if (!empty($brand_has_model_ids)) {
            $query .= $status == 0 ? " WHERE `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")" : " AND `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")";
            $status = 1;
        }
    }

    if ($brand == 0 && $model != 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `model_id`='" . $model . "'");
        $brand_has_model_ids = [];
        while ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $brand_has_model_ids[] = $brand_has_model_data["id"];
        }
        if (!empty($brand_has_model_ids)) {
            $query .= $status == 0 ? " WHERE `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")" : " AND `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")";
            $status = 1;
        }
    }

    if ($brand != 0 && $model != 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `brand_id`='" . $brand . "' AND `model_id`='" . $model . "'");
        if ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $pid = $brand_has_model_data["id"];
            $query .= $status == 0 ? " WHERE `brand_has_model_id`='" . $pid . "'" : " AND `brand_has_model_id`='" . $pid . "'";
            $status = 1;
        }
    }

    if ($condition != 0) {
        $query .= $status == 0 ? " WHERE `condition_id`='" . $condition . "'" : " AND `condition_id`='" . $condition . "'";
        $status = 1;
    }

    if (!empty($price_from) && empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` >= '" . $price_from . "'" : " AND `price` >= '" . $price_from . "'";
        $status = 1;
    }

    if (empty($price_from) && !empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` <= '" . $price_to . "'" : " AND `price` <= '" . $price_to . "'";
        $status = 1;
    }

    if (!empty($price_from) && !empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` BETWEEN '" . $price_from . "' AND '" . $price_to . "'" : " AND `price` BETWEEN '" . $price_from . "' AND '" . $price_to . "'";
        $status = 1;
    }

    $query .= " ORDER BY `date_time` DESC";
} else if ($sort == 4) {
    if (!empty($search_txt)) {
        $query .= " WHERE `title` LIKE '%" . $search_txt . "%'";
        $status = 1;
    }

    if ($category != 0) {
        $query .= $status == 0 ? " WHERE `category_id`='" . $category . "'" : " AND `category_id`='" . $category . "'";
        $status = 1;
    }

    $pid = 0;
    if ($brand != 0 && $model == 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `brand_id`='" . $brand . "'");
        $brand_has_model_ids = [];
        while ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $brand_has_model_ids[] = $brand_has_model_data["id"];
        }
        if (!empty($brand_has_model_ids)) {
            $query .= $status == 0 ? " WHERE `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")" : " AND `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")";
            $status = 1;
        }
    }

    if ($brand == 0 && $model != 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `model_id`='" . $model . "'");
        $brand_has_model_ids = [];
        while ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $brand_has_model_ids[] = $brand_has_model_data["id"];
        }
        if (!empty($brand_has_model_ids)) {
            $query .= $status == 0 ? " WHERE `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")" : " AND `brand_has_model_id` IN (" . implode(',', $brand_has_model_ids) . ")";
            $status = 1;
        }
    }

    if ($brand != 0 && $model != 0) {
        $brand_has_model_rs = Database::search("SELECT * FROM `brand_has_model` WHERE `brand_id`='" . $brand . "' AND `model_id`='" . $model . "'");
        if ($brand_has_model_data = $brand_has_model_rs->fetch_assoc()) {
            $pid = $brand_has_model_data["id"];
            $query .= $status == 0 ? " WHERE `brand_has_model_id`='" . $pid . "'" : " AND `brand_has_model_id`='" . $pid . "'";
            $status = 1;
        }
    }

    if ($condition != 0) {
        $query .= $status == 0 ? " WHERE `condition_id`='" . $condition . "'" : " AND `condition_id`='" . $condition . "'";
        $status = 1;
    }

    if (!empty($price_from) && empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` >= '" . $price_from . "'" : " AND `price` >= '" . $price_from . "'";
        $status = 1;
    }

    if (empty($price_from) && !empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` <= '" . $price_to . "'" : " AND `price` <= '" . $price_to . "'";
        $status = 1;
    }

    if (!empty($price_from) && !empty($price_to)) {
        $query .= $status == 0 ? " WHERE `price` BETWEEN '" . $price_from . "' AND '" . $price_to . "'" : " AND `price` BETWEEN '" . $price_from . "' AND '" . $price_to . "'";
        $status = 1;
    }

    $query .= " ORDER BY `date_time` ASC";
}


$pageno;

if ("0" != ($_POST["page"])) {
    $pageno = $_POST["page"];
} else {
    $pageno = 1;
}

$result = Database::search($query);
$product_num =  $result->num_rows;

$results_per_page = 5;
$number_of_pages = ceil($product_num / $results_per_page);

$page_results = ($pageno - 1) * $results_per_page;



$final_query = $query . " LIMIT " . $results_per_page . " OFFSET " . $page_results;


$selected_rs = Database::search($final_query);
$selected_num = $selected_rs->num_rows;



if ($selected_num == 0) { ?>
    <span style="font-size: 30px;">Searched Product does not exist 🙁</span>

<?php
} else {
?>
    <h2>Results :-</h2>
    <?php
    for ($z = 0; $z < $product_num; $z++) {
        $product_data = $result->fetch_assoc();
    ?>
        <div class="ad-item" style="background-color: #000000">
            <?php
            $img_rs = Database::search("SELECT * FROM `product_image` WHERE `product_id`='" . $product_data["id"] . "'");
            $img_data = $img_rs->fetch_assoc();
            ?>
            <div class="row">
                <div class="col-md-8">
                    <div class="ad-title">
                        <h5 class="card-title fw-semibold fs-2" style="font-size: 25px; "><?php echo $product_data["title"]; ?></h5>
                    </div>
                    <div class="ad-price">
                        <?php
                        if ($product_data["updated_price"] == "") {
                        ?> <td>
                                <span style="font-size: 20px; ">Rs. <?php echo $product_data["price"]; ?> .00</span>
                            </td>


                        <?php
                        } else {
                        ?>
                            <td>

                                <span class="original-price" style="font-size: 20px; ">Rs. <?php echo $product_data["price"]; ?> .00</span>
                                <span class="discounted-price" style="font-size: 20px; ">Rs. <?php echo $product_data["updated_price"]; ?> .00</span>

                            </td>
                        <?php
                        }
                        ?>
                        &nbsp;&nbsp;&nbsp;
                        <?php
                        if ($product_data['condition_id'] == 1) {
                        ?>
                            <span class="badge rounded-pill text-bg-info" style="font-size: 15px;">New</span>
                        <?php
                        } else {
                        ?>
                            <span class="badge rounded-pill text-bg-warning" style="font-size: 15px;">Used</span>
                        <?php
                        }
                        ?>
                    </div>

                    <img src="<?php echo $img_data["img_path"]; ?>" alt="Ad Image" class="img-fluid" style="width:200px">
                </div>
                <div class="col-md-4 d-flex flex-column justify-content-around">
                    <a href='<?php echo "singleProductView.php?id=" . ($product_data["id"]); ?>' class="col-12 btn button-green bt" style="background-color:#;">
                        View Product
                    </a>

                    <?php if (isset($_SESSION["u"])) {
                    ?>
                        <button class="col-12 btn btn-dark mt-2 bt" onclick="addToCart(<?php echo $product_data['id']; ?>);">
                            <i class="bi bi-cart-plus-fill text-white fs-5"></i>
                        </button>
                        <?php

                        $watchlist_rs = Database::search("SELECT * FROM `watchlist` WHERE `user_email`='" . $_SESSION["u"]["email"] . "' 
                                                                        AND `product_id`='" . $product_data["id"] . "'");
                        $watchlist_num = $watchlist_rs->num_rows;

                        if ($watchlist_num == 1) {
                        ?>
                            <button class="col-12 btn btn-outline-light mt-2 border border-primary" onclick='addToWatchlist(<?php echo $product_data["id"]; ?>);'>
                                <i class="bi bi-heart-fill text-danger fs-5" id="heart<?php echo $product_data["id"]; ?>"></i>
                            </button>
                        <?php
                        } else {
                        ?>
                            <button class="col-12 btn btn-outline-light mt-2 border border-primary" onclick='addToWatchlist(<?php echo $product_data["id"]; ?>);'>
                                <i class="bi bi-heart-fill text-dark fs-5" id="heart<?php echo $product_data["id"]; ?>"></i>
                            </button>
                    <?php
                        }
                    }


                    ?>
                </div>
            </div>
        </div>



    <?php
    }
    ?>
    <div class="offset-2 offset-lg-3 col-8 col-lg-6 text-center mb-3">
        <nav aria-label="Page navigation example">
            <ul class="pagination pagination-lg justify-content-center">
                <li class="page-item">
                    <a class="page-link bg-secondary text-white" <?php if ($pageno <= 1) {
                                                                        echo 'href="#"';
                                                                    } else { ?> onclick="SearchType(<?php echo ($pageno - 1); ?>);" <?php } ?> aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>

                <?php for ($x = 1; $x <= $number_of_pages; $x++) {
                    $active = ($x == $pageno) ? 'active' : '';
                ?>
                    <li class="page-item <?php echo $active; ?>">
                        <a class="page-link" onclick="SearchType(<?php echo ($x); ?>);"><?php echo $x; ?></a>
                    </li>
                <?php } ?>

                <li class="page-item">
                    <a class="page-link bg-secondary text-white" <?php if ($pageno >= $number_of_pages) {
                                                                        echo 'href="#"';
                                                                    } else { ?> onclick="SearchType(<?php echo ($pageno + 1); ?>);" <?php } ?> aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
<?php
}
?>