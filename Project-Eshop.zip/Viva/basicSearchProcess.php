
<link rel="stylesheet" href="styles/pagination.css">
<?php
include "connection.php";
session_start();


$txt = $_POST["t"];
$query = "SELECT * FROM `product` WHERE `status_id` = '1'";

if (!empty($txt)) {
    $query .= " AND `title` LIKE '%$txt%'";

?>

    <div class="row">
        <div class="offset-lg-1 col-12 col-lg-10 text-center">
            <div class="row">

                <?php
                $pageno;

                if ("0" != ($_POST["page"])) {
                    $pageno = $_POST["page"];
                } else {
                    $pageno = 1;
                }

                $product_rs = Database::search($query);
                $product_num = $product_rs->num_rows;

                $results_per_page = 5;
                $number_of_pages = ceil($product_num / $results_per_page);

                $page_results = ($pageno - 1) * $results_per_page;



                $final_query = $query . " LIMIT " . $results_per_page . " OFFSET " . $page_results;


                $selected_rs = Database::search($final_query);
                $selected_num = $selected_rs->num_rows;

                $selected_rs = Database::search($final_query);
                $selected_num = $selected_rs->num_rows;

                if ($selected_num == 0) { ?>
                    <span style="font-size: 30px;">Product does not exist 🙁</span>
                <?php } else { ?>
                    <h2>~~Results~~</h2>
                    <?php
                    for ($x = 0; $x < $selected_num; $x++) {
                        $product_data = $selected_rs->fetch_assoc();
                    ?>
                        <div class="ad-item" style="background-color: black;">
                            <?php
                            $img_rs = Database::search("SELECT * FROM `product_image` WHERE `product_id`='" . $product_data["id"] . "'");
                            $img_data = $img_rs->fetch_assoc();
                            ?>
                            <div class="row">
                                <div class="col-md-8">
                                    <div class="ad-title">
                                        <h5 class="card-title fw-semibold fs-2" style="font-size: 25px;"><?php echo $product_data["title"]; ?></h5>
                                    </div>
                                    <div class="ad-price">
                                        <?php if ($product_data["updated_price"] == "") { ?>
                                            <span style="font-size: 20px;">Rs. <?php echo $product_data["price"]; ?> .00</span>
                                        <?php } else { ?>
                                            <span class="original-price" style="font-size: 20px;">Rs. <?php echo $product_data["price"]; ?> .00</span>
                                            <span class="discounted-price" style="font-size: 20px;">Rs. <?php echo $product_data["updated_price"]; ?> .00</span>
                                        <?php } ?>
                                        <?php
                                    if ($product_data['condition_id'] == 1) {
                                    ?>
                                        <span class="badge rounded-pill text-bg-info" style="font-size: 15px;">New</span>
                                    <?php
                                    } else {
                                    ?>
                                        <span class="badge rounded-pill text-bg-warning" style="font-size: 15px;">Used</span>
                                    <?php
                                    }
                                    ?>
                                    </div>
                                    <img src="<?php echo $img_data["img_path"]; ?>" alt="Ad Image" class="img-fluid" style="width:200px">
                                </div>
                                <div class="col-md-4 d-flex flex-column justify-content-around">
                                    <a href='<?php echo "singleProductView.php?id=" . ($product_data["id"]); ?>' class="col-12 btn button-green bt" style="background-color:#;">
                                        View Product
                                    </a>
                                    <button class="col-12 btn btn-dark mt-2" onclick="addToCart(<?php echo $product_data['id']; ?>);">
                                        <i class="bi bi-cart-plus-fill text-white fs-5"></i>
                                    </button>
                                    <?php if (isset($_SESSION["u"])) {
                                        $watchlist_rs = Database::search("SELECT * FROM `watchlist` WHERE `user_email`='" . $_SESSION["u"]["email"] . "' 
                                                                        AND `product_id`='" . $product_data["id"] . "'");
                                        $watchlist_num = $watchlist_rs->num_rows;

                                        if ($watchlist_num == 1) { ?>
                                            <button class="col-12 btn btn-outline-light mt-2 border border-primary" onclick='addToWatchlistSearch(<?php echo $product_data["id"]; ?>);'>
                                                <i class="bi bi-heart-fill text-danger fs-5" id="heart<?php echo $product_data["id"]; ?>"></i>
                                            </button>
                                        <?php } else { ?>
                                            <button class="col-12 btn btn-outline-light mt-2 border border-primary" onclick='addToWatchlistSearch(<?php echo $product_data["id"]; ?>);'>
                                                <i class="bi bi-heart-fill text-dark fs-5" id="heart<?php echo $product_data["id"]; ?>"></i>
                                            </button>
                                    <?php }
                                    } ?>
                                </div>
                            </div>
                        </div>
                    <?php } ?>

                    <div class="offset-2 offset-lg-3 col-8 col-lg-6 text-center mb-3">
                        <nav aria-label="Page navigation example">
                            <ul class="pagination pagination-lg justify-content-center">
                                <li class="page-item">
                                    <a class="page-link bg-secondary text-white" <?php if ($pageno <= 1) {
                                                                                echo 'href="#"';
                                                                            } else { ?> onclick="SearchType(<?php echo ($pageno - 1); ?>);" <?php } ?> aria-label="Previous">
                                        <span aria-hidden="true">&laquo;</span>
                                    </a>
                                </li>

                                <?php for ($x = 1; $x <= $number_of_pages; $x++) {
                                    $active = ($x == $pageno) ? 'active' : '';
                                ?>
                                    <li class="page-item <?php echo $active; ?>">
                                        <a class="page-link" onclick="SearchType(<?php echo ($x); ?>);"><?php echo $x; ?></a>
                                    </li>
                                <?php } ?>

                                <li class="page-item">
                                    <a class="page-link bg-secondary text-white" <?php if ($pageno >= $number_of_pages) {
                                                                                echo 'href="#"';
                                                                            } else { ?> onclick="SearchType(<?php echo ($pageno + 1); ?>);" <?php } ?> aria-label="Next">
                                        <span aria-hidden="true">&raquo;</span>
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>


<?php
} else if (empty($txt)) { ?>
    <Span style="font-size: 30px;">Please type a product name 😐 </Span>
    <?php

    ?>


<?php
}
?>