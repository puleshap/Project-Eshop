<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GamerShop | Home </title>
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="bootstrap1.css" />
    <link rel="stylesheet" href="styles/pagination.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="icon" href="resource/logo.png" />

</head>

<body style="  background: linear-gradient(to bottom, #002d5b, #000000);color: #ffffff;">
    <?php include "header2.php"; ?>
    <div class="container my-4">
        <hr style=" height: 2px; background-color: #ffffff; ">
        <!-- Basic Search Section-->
        <div class="search-section mb-5" style="  background-color: #00b4d8; color: #ffffff;padding: 20px;">
            <h4 class="text-center text-black" style=" font-weight: bold;">What are you looking for?</h4>
            <div class="input-group">
                <input type="text" class="form-control" placeholder="Search..." id="basic_search_txt">
                <div class="input-group-append">
                    <button class="btn btn-warning" type="button" onclick="SearchType(0);">Search</button>
                </div>
            </div>
        </div>
        <!-- Basic Search Section-->


        <hr style=" height: 2px; background-color: #ffffff; ">
        <div class="row">
            <!-- Advanced Search Section-->
            <div class="col-md-3  " style="background-color:#002d5b ;">
                <h5>A d v a n c e d &nbsp;&nbsp;&nbsp;&nbsp;&nbsp; S e t t i n g s</h5>
                <hr style=" height: 2px; background-color: #ffffff; ">
                <div class="form-check">
                    <select class="form-select text-white" style="background-color:#002d5b ;" id="category" onchange="load_brand();">
                        <option value="0">Select Category</option>
                        <?php


                        $category_rs = Database::search("SELECT * FROM `category`");
                        $category_num = $category_rs->num_rows;

                        for ($x = 0; $x < $category_num; $x++) {
                            $category_data = $category_rs->fetch_assoc();
                        ?>
                            <option value="<?php echo $category_data["id"]; ?>">
                                <?php echo $category_data["category_name"]; ?>
                            </option>
                        <?php
                        }

                        ?>
                    </select>
                </div>
                <div class="form-check">
                    <select class="form-select text-white" style="background-color:#002d5b ;" id="brand" onchange="load_model();">
                        <option value="0">Select Brand</option>

                    </select>
                </div>
                <div class="form-check">
                    <select class="form-select text-white" style="background-color:#002d5b ;" id="model">
                        <option value="0">Select Model</option>

                    </select>
                </div>
                <hr style=" height: 2px; background-color: #ffffff; ">
                <div class="form-check">
                    <select class="form-select text-white" style="background-color:#002d5b ;" id="c2">
                        <option value="0">Select Condition</option>
                        <?php
                        $condition_rs = Database::search("SELECT * FROM `condition`");
                        $condition_num = $condition_rs->num_rows;

                        for ($x = 0; $x < $condition_num; $x++) {
                            $condition_data = $condition_rs->fetch_assoc();
                        ?>
                            <option value="<?php echo $condition_data["id"]; ?>">
                                <?php echo $condition_data["name"]; ?>
                            </option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                <br>
                <h6>Price Range</h6>

                <div class="mx-5">
                    <input type="text" class="form-control text-white" style="background-color:#002d5b ;" placeholder="Price From..." id="pf" />
                </div>
                <br>
                <div class="mx-5">
                    <input type="text" class="form-control text-white" style="background-color:#002d5b ;" placeholder="Price To..." id="pt" />
                </div>
                <hr style=" height: 2px; background-color: #ffffff; ">
                <div class="mx-5">
                    <select id="s" class="form-select border  border-1 border-white text-white" style="background-color:#002d5b ;">
                        <option value="0">Sort By</option>
                        <option value="1">Price high to low</option>
                        <option value="2">Price low to high</option>
                        <option value="1">Newest to Oldest</option>
                        <option value="2">Oldest to Newest</option>


                    </select>
                </div>
                <hr style=" height: 2px; background-color: #ffffff; ">
                <br>
                <div class="mx-5 mb-5 ">
                    <button class="mx-5 btn btn-primary" onclick="advancedSearch(0);">Apply Settings</button>
                </div>

                <hr style=" height: 2px; background-color: #ffffff; ">
            </div>
            <!-- Advanced Search Section-->
            <!-- Product Content Section-->
            <div class="col-md-5 main-content" id="main-content">
                <h2>~~Latest Products~~</h2>
                <?php
                $product_rs = Database::search("SELECT * FROM `product` WHERE  
                            `status_id`='1' ORDER BY `date_time` DESC LIMIT 4 ");

                $product_num = $product_rs->num_rows;

                for ($z = 0; $z < $product_num; $z++) {
                    $product_data = $product_rs->fetch_assoc();
                ?>
                    <div class="ad-item" style="background-color: #000000">
                        <?php
                        $img_rs = Database::search("SELECT * FROM `product_image` WHERE `product_id`='" . $product_data["id"] . "'");
                        $img_data = $img_rs->fetch_assoc();
                        ?>
                        <div class="row">
                            <div class="col-md-8">
                                <div class="ad-title">
                                    <h5 class="card-title fw-semibold fs-2" style="font-size: 25px; "><?php echo $product_data["title"]; ?></h5>
                                </div>
                                <div class="ad-price">
                                    <?php
                                    if ($product_data["updated_price"] == "") {
                                    ?> <td>
                                            <span style="font-size: 20px; ">Rs. <?php echo $product_data["price"]; ?> .00</span>
                                        </td>


                                    <?php
                                    } else {
                                    ?>
                                        <td>

                                            <span class="original-price" style="font-size: 20px; ">Rs. <?php echo $product_data["price"]; ?> .00</span>
                                            <span class="discounted-price" style="font-size: 20px; ">Rs. <?php echo $product_data["updated_price"]; ?> .00</span>

                                        </td>
                                    <?php
                                    }
                                    ?>
                                    &nbsp;&nbsp;&nbsp;
                                    <?php
                                    if ($product_data['condition_id'] == 1) {
                                    ?>
                                        <span class="badge rounded-pill text-bg-info" style="font-size: 15px;">New</span>
                                    <?php
                                    } else {
                                    ?>
                                        <span class="badge rounded-pill text-bg-warning" style="font-size: 15px;">Used</span>
                                    <?php
                                    }
                                    ?>
                                </div>

                                <img src="<?php echo $img_data["img_path"]; ?>" alt="Ad Image" class="img-fluid" style="width:200px">
                            </div>
                            <div class="col-md-4 d-flex flex-column justify-content-around">
                                <a href='<?php echo "singleProductView.php?id=" . ($product_data["id"]); ?>' class="col-12 btn button-green bt" style="background-color:#;">
                                    View Product
                                </a>

                                <?php if (isset($_SESSION["u"])) {
                                ?>
                                    <button class="col-12 btn btn-dark mt-2 bt" onclick="addToCart(<?php echo $product_data['id']; ?>);">
                                        <i class="bi bi-cart-plus-fill text-white fs-5"></i>
                                    </button>
                                    <?php

                                    $watchlist_rs = Database::search("SELECT * FROM `watchlist` WHERE `user_email`='" . $_SESSION["u"]["email"] . "' 
                                                                        AND `product_id`='" . $product_data["id"] . "'");
                                    $watchlist_num = $watchlist_rs->num_rows;

                                    if ($watchlist_num == 1) {
                                    ?>
                                        <button class="col-12 btn btn-outline-light mt-2 border border-primary" onclick='addToWatchlist(<?php echo $product_data["id"]; ?>);'>
                                            <i class="bi bi-heart-fill text-danger fs-5" id="heart<?php echo $product_data["id"]; ?>"></i>
                                        </button>
                                    <?php
                                    } else {
                                    ?>
                                        <button class="col-12 btn btn-outline-light mt-2 border border-primary" onclick='addToWatchlist(<?php echo $product_data["id"]; ?>);'>
                                            <i class="bi bi-heart-fill text-dark fs-5" id="heart<?php echo $product_data["id"]; ?>"></i>
                                        </button>
                                <?php
                                    }
                                }


                                ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <!-- Product Content Section-->
            <div class="col-md-3 " style="background-color:#002d5b ;">


                <hr>
                <div>
                    <h5 class="category-title text-center">Top Categories</h5>
                    <hr>
                    <?php
                    $details_rs = Database::search("SELECT * FROM `Category` LIMIT 10 ");
                    $cat_num = $details_rs->num_rows;
                    for ($x = 0; $x < $cat_num; $x++) {
                        $category_data = $details_rs->fetch_assoc();
                    ?>


                        <div class="category-item text-center">
                            <label class="text-decoration-none"><?php echo ($category_data['category_name']) ?></label>

                        </div>
                    <?php }
                    ?>

                </div>
                <div>
                    <hr>
                    <h5 class="category-title text-center">Available Brands</h5>
                    <hr>
                    <?php
                    $details_rs = Database::search("SELECT * FROM `Brand` LIMIT 10 ");
                    $cat_num = $details_rs->num_rows;
                    for ($x = 0; $x < $cat_num; $x++) {
                        $category_data = $details_rs->fetch_assoc();
                    ?>


                        <div class="category-item text-center">
                            <label class="text-decoration-none"><?php echo ($category_data['brand_name']) ?></label>

                        </div>
                    <?php }
                    ?>
                    <hr>
                </div>

            </div>
        </div>
    </div>
    <?php include "footer.php";
    ?>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>

</body>

</html>
<style>
    body {
        background: linear-gradient(to bottom, #002d5b, #000000);
        color: #ffffff;
    }

    a {
        color: #00b4d8;
        text-decoration: none;
    }

    a:hover {
        color: #00a6fb;
    }

    button,
    .bt {
        background-color: #00b4d8;
        color: #ffffff;
        border: none;
        padding: 10px 20px;
        cursor: pointer;
    }

    button:hover,
    .btn:hover {
        background-color: #00a6fb;
    }

    .button-green {
        background-color: #28a745;
        /* Brighter green */
    }

    .button-green:hover {
        background-color: #218838;
        /* Slightly darker green */
    }

    .header,
    .footer {
        background-color: #002d5b;
        color: #ffffff;
        padding: 20px;
    }

    .icon {
        color: #00b4d8;
    }

    .input,
    select {
        background-color: #002d5b;
        color: #ffffff;
        border: 1px solid #00b4d8;
        padding: 5px 10px;
        margin: 5px 0;
        border-radius: 4px;
        transition: border-color 0.3s ease;
    }

    .input:hover,
    select:hover {
        border-color: #00a6fb;
    }

    .container {
        padding: 20px;
    }
</style>
<style>
    body {
        background-color: #343a40;
    }

    .search-section {
        background-color: #28a745;
        padding: 30px 0;
        text-align: center;
    }

    .search-section h4 {
        margin-bottom: 20px;
    }

    .search-section .input-group {
        width: 50%;
        margin: 0 auto;
    }

    .sidebar {
        background-color: #ffffff;
        padding: 15px;
        border-right: 1px solid #dee2e6;
        border-left: 1px solid #dee2e6;
    }

    .main-content {
        padding: 15px;
    }

    .navbar {
        background-color: #343a40;
    }

    .navbar-dark .navbar-nav .nav-link {
        color: #ffffff;
    }

    .category-title {
        font-size: 1.2em;
        font-weight: bold;
        margin-top: 15px;
    }

    .category-item {
        margin-bottom: 10px;
    }

    .ad-item {
        background-color: #ffffff;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #dee2e6;
        border-radius: 5px;
    }

    .ad-item img {
        max-width: 100%;
        height: 150px;
        display: block;
        margin-bottom: 10px;
    }

    .ad-title {
        font-size: 1.1em;
        font-weight: bold;
    }

    .ad-price {
        color: #28a745;
        font-weight: bold;
    }
</style>