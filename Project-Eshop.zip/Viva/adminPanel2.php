<?php

session_start();
include "connection.php";

if (isset($_SESSION["au"])) {

?>

    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Admin Panel | GamerShop</title>
        <link rel="stylesheet" href="bootstrap.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
        <link rel="stylesheet" href="style.css" />
        <link rel="stylesheet" href="styles/Admin_User_Panel.css" />

        <link rel="icon" href="resource/logo.png" />
    </head>

    <body style="  background-color:#002d5b;color: #ffffff; ">

        <div class="container-fluid over">
            <div class="row">

                <div class="col-12 col-lg-2">
                    <div class="row">
                        <div class="col-12 align-items-start bg-dark vh-100">
                            <div class="row g-1 text-center">
                                <?php
                                $rs = Database::search("SELECT * FROM `reports` WHERE `status` ='1'");
                                $rs_num = $rs->num_rows;

                                ?>
                                <div class="col-12 mt-5">
                                    <h4 class="text-white"><?php echo $_SESSION["au"]["fname"] . " " . $_SESSION["au"]["lname"]; ?></h4>
                                    <hr class="border border-1 border-white" />
                                </div>
                                <div class="nav flex-column nav-pills me-3 mt-3" role="tablist" aria-orientation="vertical">
                                    <nav class="nav flex-column">
                                        <a class="btn btn-outline-primary" href="adminPanel.php"><label class="fw-bold"> Dashboard</label> </a> <br>

                                        <a class="nav-link active mb-4 " aria-current="page" href="#"><label class="fw-bold"> Management</label></a>
                                        <a class="nav-link mb-4 text-info btn-outline-info btn" onclick="AdminShowUserPanel();"><label class="fw-bold "> Manage Users</label></a>
                                        <a class="nav-link mb-4 text-info  btn-outline-info btn" onclick="AdminShowCategoryPanel();"><label class="fw-bold"> Manage Categories</label> </a>

                                        <a class="nav-link mb-4 text-info btn-outline-info btn" onclick="AdminShowBrandPanel();"><label class="fw-bold"> Manage brands</label> </a>
                                        <a class="nav-link mb-4 text-info btn-outline-info btn" onclick="AdminShowModelPanel();"><label class="fw-bold"> Manage Models</label> </a>
                                        <a class="nav-link  mb-4  text-info btn-outline-info btn" onclick="AdminShowProductPanel();"><label class="fw-bold"> Manage Products</label> </a>
                                        <a class="btn btn-outline-primary" href="adminPanel3.php"><label class="fw-bold"> Reports
                                                <?php if ($rs_num > 0) { ?>
                                                    🛑
                                                <?php
                                                }  ?>
                                            </label> </a>

                                    </nav>
                                </div>
                                <div class="col-12 mt-5 ">
                                    <hr class="border border-1 border-white" />
                                    <button class="btn btn-outline-danger" onclick="signout();">LogOut</button>
                                    <hr class="border border-1 border-white" />
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-10">
                    <div class="row">

                        <div class="text-white fw-bold mb-1 mt-3">
                        <h2 class="fw-bold">Gamer Shop Admin Dashboard</h2>
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>

                        <div class="col-12">
                            <div class="row g-1 mt-2" id="ShowPanel">



                                <div class="col-12 bg-dark text-center">
                                    <label class="form-label text-primary fw-bold fs-1"> U s e r &nbsp; &nbsp; M a n a g e m e n t &nbsp; &nbsp; P a n e l</label>
                                </div>

                                <div class="container">
                                    <br>

                                    <div class="search-bar">

                                        <input type="text" id="searchUsers" placeholder="Search Email" class="rounded rounded-3">
                                        <button id="searchButton " class=" rounded rounded-3 border border-3" onclick="SearchUserPanel();">🔍</button>

                                    </div>
                                    <br>
                                    <div class="table-wrapper">
                                        <table id="userTable">
                                            <thead>
                                                <tr>
                                                    <th class="bg-secondary fw-light text-center">Name</th>
                                                    <th class="bg-secondary fw-light text-center">Profile Image</th>
                                                    <th class="bg-secondary fw-light text-center">Email</th>
                                                    <th class="bg-secondary fw-light text-center">Mobile</th>
                                                    <th class="bg-secondary fw-light text-center">Creted On</th>
                                                    <th class="bg-secondary fw-light text-center">Status</th>


                                                    <th class="bg-secondary fw-light text-center">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody id="tbody">
                                                <?php

                                                $query = "SELECT * FROM `user`";
                                                $pageno;

                                                if (isset($_GET["page"])) {
                                                    $pageno = $_GET["page"];
                                                } else {
                                                    $pageno = 1;
                                                }

                                                $user_rs = Database::search($query);
                                                $user_num = $user_rs->num_rows;

                                                $selected_rs = Database::search($query);

                                                $selected_num = $selected_rs->num_rows;

                                                for ($x = 0; $x < $selected_num; $x++) {
                                                    $selected_data = $selected_rs->fetch_assoc();

                                                ?>

                                                    <tr>
                                                        <td><?php echo $selected_data["fname"] . " " . $selected_data["lname"]; ?></td>
                                                        <td><?php
                                                            $profile_image_rs = Database::search("SELECT * FROM `profile_image` WHERE 
                                                                         `user_email`='" . $selected_data["email"] . "'");
                                                            $profile_image_num = $profile_image_rs->num_rows;

                                                            if ($profile_image_num == 1) {
                                                                $profile_image_data = $profile_image_rs->fetch_assoc();
                                                            ?>
                                                                <img src="<?php echo $profile_image_data["path"]; ?>" style="height: 40px;margin-left: 60px;" />
                                                            <?php
                                                            } else {
                                                            ?>
                                                                <img src="resource/new_user.svg" style="height: 40px;margin-left: 50px;" />
                                                            <?php
                                                            }
                                                            ?>
                                                        </td>
                                                        <td><?php echo ($selected_data["email"]); ?></td>
                                                        <td><?php echo $selected_data["mobile"]; ?></td>
                                                        <td> <?php
                                                                $splitDate = explode(" ", $selected_data["joined_date"]);
                                                                ?>
                                                            <span class=" "><?php echo $splitDate[0]; ?></span>
                                                        </td>
                                                        <?php
                                                        if ($selected_data["status_id"] == 1) {
                                                        ?>
                                                            <td class="status text-center">Active</td>
                                                        <?php
                                                        } else {
                                                        ?>
                                                            <td class="status-red text-center">Deactive</td>
                                                        <?php
                                                        }
                                                        ?>
                                                        <td class="actions text-center">
                                                            <?php
                                                            if ($selected_data["status_id"] == 1) {
                                                            ?>
                                                                <button onclick="blockUser('<?php echo $selected_data['email']; ?>');">🔒</button>
                                                            <?php
                                                            } else {
                                                            ?>
                                                                <button onclick="blockUser('<?php echo $selected_data['email']; ?>');">🔑</button>
                                                            <?php
                                                            }
                                                            ?>


                                                        </td>
                                                    </tr>

                                                <?php

                                                }
                                                ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="col-12">
                            <hr />
                        </div>





                    </div>
                </div>

            </div>
        </div>

        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>
        <script src="AdminScript.js"></script>
    </body>

    </html>

<?php

} else {
    echo ("You are not a valid user.");
}

?>