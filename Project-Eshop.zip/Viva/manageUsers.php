<?php

require "connection.php";

?>

<link rel="stylesheet" href="bootstrap.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="style.css" />
<link rel="stylesheet" href="styles/Admin_User_Panel.css" />


<div class="col-12 bg-dark text-center">
    <label class="form-label text-primary fw-bold fs-1"> U s e r &nbsp; &nbsp; M a n a g e m e n t &nbsp; &nbsp; P a n e l</label>
</div>

<div class="container">
    <br>

    <div class="search-bar">

        <input type="text" id="searchUsers" placeholder="Search Email" class="rounded rounded-3">
        <button id="searchButton " class=" rounded rounded-3 border border-3" onclick="SearchUserPanel();">🔍</button>

    </div>
    <br>
    <div class="table-wrapper">
                                        <table id="userTable">
                                            <thead>
                                                <tr>
                                                    <th class="bg-secondary fw-light text-center">Name</th>
                                                    <th class="bg-secondary fw-light text-center">Profile Image</th>
                                                    <th class="bg-secondary fw-light text-center">Email</th>
                                                    <th class="bg-secondary fw-light text-center">Mobile</th>
                                                    <th class="bg-secondary fw-light text-center">Creted On</th>
                                                    <th class="bg-secondary fw-light text-center">Status</th>


                                                    <th class="bg-secondary fw-light text-center">Actions</th>
                                                </tr>
                                            </thead>
                                            <tbody id="tbody">
                                                <?php

                                                $query = "SELECT * FROM `user`";
                                                $pageno;

                                                if (isset($_GET["page"])) {
                                                    $pageno = $_GET["page"];
                                                } else {
                                                    $pageno = 1;
                                                }

                                                $user_rs = Database::search($query);
                                                $user_num = $user_rs->num_rows;

                                                $selected_rs = Database::search($query);

                                                $selected_num = $selected_rs->num_rows;

                                                for ($x = 0; $x < $selected_num; $x++) {
                                                    $selected_data = $selected_rs->fetch_assoc();

                                                ?>

                                                    <tr>
                                                        <td><?php echo $selected_data["fname"] . " " . $selected_data["lname"]; ?></td>
                                                        <td><?php
                                                            $profile_image_rs = Database::search("SELECT * FROM `profile_image` WHERE 
                                                                         `user_email`='" . $selected_data["email"] . "'");
                                                            $profile_image_num = $profile_image_rs->num_rows;

                                                            if ($profile_image_num == 1) {
                                                                $profile_image_data = $profile_image_rs->fetch_assoc();
                                                            ?>
                                                                <img src="<?php echo $profile_image_data["path"]; ?>" style="height: 40px;margin-left: 60px;" />
                                                            <?php
                                                            } else {
                                                            ?>
                                                                <img src="resource/new_user.svg" style="height: 40px;margin-left: 50px;" />
                                                            <?php
                                                            }
                                                            ?>
                                                        </td>
                                                        <td><?php echo ($selected_data["email"]); ?></td>
                                                        <td><?php echo $selected_data["mobile"]; ?></td>
                                                        <td> <?php
                                                                $splitDate = explode(" ", $selected_data["joined_date"]);
                                                                ?>
                                                            <span class=" "><?php echo $splitDate[0]; ?></span>
                                                        </td>
                                                        <?php
                                                        if ($selected_data["status_id"] == 1) {
                                                        ?>
                                                            <td class="status text-center">Active</td>
                                                        <?php
                                                        } else {
                                                        ?>
                                                            <td class="status-red text-center">Deactive</td>
                                                        <?php
                                                        }
                                                        ?>
                                                        <td class="actions text-center">
                                                            <?php
                                                            if ($selected_data["status_id"] == 1) {
                                                            ?>
                                                                <button onclick="blockUser('<?php echo $selected_data['email']; ?>');">🔒</button>
                                                            <?php
                                                            } else {
                                                            ?>
                                                                <button onclick="blockUser('<?php echo $selected_data['email']; ?>');">🔑</button>
                                                            <?php
                                                            }
                                                            ?>


                                                        </td>
                                                    </tr>

                                                <?php

                                                }
                                                ?>

                                            </tbody>
                                        </table>
                                    </div>
</div>

<script src="bootstrap.bundle.js"></script>
<script src="script.js"></script>