<!DOCTYPE html>

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>User Profile | GamerShop</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-alpha1/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="style.css" />

    <link rel="icon" href="resource/logo.png" />

</head>


<body style="  background: linear-gradient(to bottom, #002d5b, #000000); color: #ffffff;">

    <div class="container-fluid">
        <div class="row">

            <?php
            require "header.php";

            include "connection.php";

            if (isset($_SESSION["u"])) {

                $email = $_SESSION["u"]["email"];

                $details_rs = Database::search("SELECT * FROM `user` INNER JOIN `gender` ON 
                        user.gender_id=gender.id WHERE `email`='" . $email . "'");

                $image_rs = Database::search("SELECT * FROM `profile_image` WHERE `user_email`='" . $email . "'");

                $address_rs = Database::search("SELECT * FROM `user_has_address` INNER JOIN `city` ON 
                        user_has_address.city_id=city.id INNER JOIN `district` ON 
                        city.district_id=district.id INNER JOIN `province` ON 
                        district.province_id=province.id WHERE `user_email`='" . $email . "'");

                $user_details = $details_rs->fetch_assoc();
                $image_details = $image_rs->fetch_assoc();
                $address_details = $address_rs->fetch_assoc();

            ?>
                <div class="col-12 " style="background-color: steelblue;">
                    <div class="row">

                        <div class="col-12  mt-4 mb-4" style="  background: linear-gradient(to bottom, #002d5b, #000000); color: #ffffff;">
                            <div class="row g-2">



                                <div class="col-12 ">
                                    <div class="p-3 py-5">

                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <h4 class="fw-bold">Profile Settings</h4>
                                        </div>
                                        <div class="d-flex flex-column align-items-center text-center p-3 py-5 ">

                                            <?php

                                            if (empty($image_details["path"])) {
                                            ?>
                                                <img src="resource/new_user.svg" class="rounded mt-5" style="width: 250px;" id="img" />
                                            <?php
                                            } else {
                                            ?>
                                                <img src="<?php echo $image_details["path"]; ?>" class="rounded mt-5" id="img" style="width: 250px;" />
                                            <?php
                                            }

                                            ?>

                                            <span class="fw-bold"><?php echo $user_details["fname"] . " " . $user_details["lname"] ?></span>
                                            <span class="fw-bold text-white-50"><?php echo $email; ?></span>

                                            <input type="file" class="d-none" id="profileimage" />
<label for="profileimage" class="btn btn-info mt-5" onclick="changeProfileImg();">Change Profile Image</label>

                                        </div>
                                        <hr>
                                        <div class="col-12 " style="background-color: #002d5b;">
                                            <label class="form-label fw-bold fs-2">Note :</label>
                                            <label class="form-label fs-5 fs-3"> &nbsp;
                                                Highlited Settings cannot be changed under any circumstance
                                            </label>
                                        </div>
                                        <hr>
                                        <div class="row mt-4">

                                            <div class="col-6">
                                                <label class="form-label">First Name</label>
                                                <input id="fname" type="text" class="form-control transparent-input text-white  bg-dark" value="<?php echo $user_details["fname"]; ?>" />
                                            </div>

                                            <div class="col-6">
                                                <label class="form-label">Last Name</label>
                                                <input id="lname" type="text" class="form-control  text-white  bg-dark" value="<?php echo $user_details["lname"]; ?>" />
                                            </div>

                                            <div class="col-12">
                                                <label class="form-label">Mobile</label>
                                                <input id="mobile" type="text" class="form-control text-white  bg-dark" value="<?php echo $user_details["mobile"]; ?>" />
                                            </div>

                                            <div class="col-12">
                                                <label class="form-label">Password</label>
                                                <div class="input-group">
                                                    <input type="password" class="form-control text-white  " style="background-color:#002d5b;" id="password" value="<?php echo $user_details["password"]; ?>" readonly />
                                                    <button class="btn border border-1" style="color:steelblue;" onclick="change1();">
                                                        <i class="bi bi-eye-slash-fill" id="eye"></i>
                                                    </button>
                                                </div>
                                            </div>

                                            <div class="col-12">
                                                <label class="form-label">Email</label>
                                                <input type="text" class="form-control text-white  " style="background-color:#002d5b;" readonly value="<?php echo $user_details["email"]; ?>" />
                                            </div>

                                            <div class="col-12">
                                                <label class="form-label">Registered Date</label>
                                                <input type="text" class="form-control text-white  y" style="background-color:#002d5b;" readonly value="<?php echo $user_details["joined_date"]; ?>" />
                                            </div>

                                            <div class="col-12">
                                                <label class="form-label">Address Line 01</label>

                                                <?php
                                                if (empty($address_details["line1"])) {
                                                ?>
                                                    <input id="line1" type="text" class="form-control  text-white  bg-dark" />
                                                <?php
                                                } else {
                                                ?>
                                                    <input id="line1" type="text" class="form-control  text-white  bg-dark" value="<?php echo $address_details["line1"]; ?>" />
                                                <?php
                                                }
                                                ?>

                                            </div>

                                            <div class="col-12">
                                                <label class="form-label">Address Line 02</label>
                                                <?php
                                                if (empty($address_details["line2"])) {
                                                ?>
                                                    <input id="line2" type="text" class="form-control text-white  bg-dark" />
                                                <?php
                                                } else {
                                                ?>
                                                    <input id="line2" type="text" class="form-control text-white  bg-dark" value="<?php echo $address_details["line2"]; ?>" />
                                                <?php
                                                }
                                                ?>
                                            </div>

                                            <?php

                                            $province_rs = Database::search("SELECT * FROM `province`");
                                            $district_rs = Database::search("SELECT * FROM `district`");
                                            $city_rs = Database::search("SELECT * FROM `city`");
                                            ?>

                                            <div class="col-6">
                                                <label class="form-label">Province</label>
                                                <select class="form-select text-white  bg-dark" id="province">
                                                    <option value="0">Select Province</option>
                                                    <?php
                                                    for ($x = 0; $x < $province_rs->num_rows; $x++) {
                                                        $province_data = $province_rs->fetch_assoc();
                                                        $province = $province_data["id"];
                                                    ?>
                                                        <option value="<?php echo $province_data["id"]; ?>" <?php
                                                                                                            if (!empty($address_details["id"])) {
                                                                                                                if ($province_data["id"] == $address_details["province_id"]) {
                                                                                                            ?>selected<?php
                                                                                                                    }
                                                                                                                }
                                                                                                                        ?>>
                                                            <?php echo $province_data["name"]; ?>
                                                        </option>
                                                    <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>

                                            <div class="col-6">
                                                <label class="form-label">District</label>
                                                <select class="form-select text-white  bg-dark" id="district">
                                                    <option value="0">Select District</option>
                                                    <?php
                                                    for ($x = 0; $x < $district_rs->num_rows; $x++) {
                                                        $district_data = $district_rs->fetch_assoc();
                                                    ?>
                                                        <option value="<?php echo $district_data["id"]; ?>" <?php
                                                                                                            if (!empty($address_details["id"])) {
                                                                                                                if ($district_data["id"] == $address_details["district_id"]) {
                                                                                                            ?>selected<?php
                                                                                                                    }
                                                                                                                }
                                                                                                                        ?>>
                                                            <?php echo $district_data["name"]; ?>
                                                        </option>
                                                    <?php
                                                    }
                                                    ?>

                                                </select>
                                            </div>

                                            <div class="col-6">
                                                <label class="form-label">City</label>
                                                <select class="form-select text-white  bg-dark" id="city">
                                                    <option value="0">Select City</option>
                                                    <?php
                                                    for ($x = 0; $x < $city_rs->num_rows; $x++) {
                                                        $city_data = $city_rs->fetch_assoc();
                                                    ?>
                                                        <option value="<?php echo $city_data["id"]; ?>" <?php
                                                                                                        if (!empty($address_details["id"])) {
                                                                                                            if ($city_data["id"] == $address_details["city_id"]) {
                                                                                                        ?>selected<?php
                                                                                                                }
                                                                                                            }
                                                                                                                    ?>>
                                                            <?php echo $city_data["name"]; ?>
                                                        </option>
                                                    <?php
                                                    }
                                                    ?>

                                                </select>
                                            </div>

                                            <div class="col-6">
                                                <label class="form-label">Postal Code</label>
                                                <?php
                                                if (empty($address_details["postal_code"])) {
                                                ?>
                                                    <input id="pcode" type="text" class="form-control text-white  bg-dark" />
                                                <?php
                                                } else {
                                                ?>
                                                    <input id="pcode" type="text" class="form-control text-white  bg-dark" value="<?php echo $address_details["postal_code"]; ?>" />
                                                <?php
                                                }
                                                ?>

                                            </div>

                                            <div class="col-12">
                                                <label class="form-label">Gender</label>
                                                <input type="text" class="form-control text-white " style="background-color:#002d5b;" value="<?php echo $user_details["gender_name"]; ?>" readonly />
                                            </div>

                                            <div class="col-12 d-grid mt-2"><br>
                                                <button class="btn btn-success" onclick="updateProfile();">Update My Profile</button>
                                            </div>

                                        </div>

                                    </div>
                                </div>



                            </div>
                        </div>

                    </div>
                </div>
            <?php

            } else {
            ?>

                <script>
                    window.location = "index.php";
                </script>

            <?php
            }

            ?>

            <?php require "footer.php"; ?>

        </div>
    </div>

    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>


</html>