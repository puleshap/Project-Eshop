<?php
include "connection.php";

if (isset($_POST["t"]) && isset($_POST["c"])) {

    $vcode = $_POST["t"];
    $cat = $_POST["c"];

    $pw = $_POST["p"];

    $admin_rs = Database::search("SELECT * FROM `admin` WHERE `email`='" . $mail . "' AND `password`='" . $pw . "'");
    $admin_num = $admin_rs->num_rows;

    if ($admin_num == 1) {
        if ($cat == 0) {
            echo ("Select Proper Category");
        } else {

            $admin_rs = Database::search("SELECT * FROM `brand` WHERE `brand_name`='" . $vcode . "'");
            $admin_num = $admin_rs->num_rows;

            if ($admin_num == 0) {


                Database::iud("INSERT INTO `brand`(`brand_name`,`category_id`) VALUES ('" . $vcode . "','$cat')");
                echo ("success");
            } else {
                echo ("Brand Already Exists..");
            }
        }
    } else {
        echo ("Invalid password.");
    }
}
