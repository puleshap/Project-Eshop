<?php

require "connection.php";

$as = $_GET["num"];
?>

<link rel="stylesheet" href="bootstrap.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<tbody id="tbody">
    <?php

    $query = "SELECT * FROM `user` WHERE  `email` LIKE '%" . $as . "%'";
    $pageno;

    if (isset($_GET["page"])) {
        $pageno = $_GET["page"];
    } else {
        $pageno = 1;
    }

    $user_rs = Database::search($query);
    $user_num = $user_rs->num_rows;

    $selected_rs = Database::search($query);

    $selected_num = $selected_rs->num_rows;
    if ($selected_num != 0) {
        for ($x = 0; $x < $selected_num; $x++) {
            $selected_data = $selected_rs->fetch_assoc();

    ?>

            <tr>
                <td><?php echo $selected_data["fname"] . " " . $selected_data["lname"]; ?></td>
                <td><?php
                    $profile_image_rs = Database::search("SELECT * FROM `profile_image` WHERE 
                            `user_email`='" . $selected_data["email"] . "'");
                    $profile_image_num = $profile_image_rs->num_rows;

                    if ($profile_image_num == 1) {
                        $profile_image_data = $profile_image_rs->fetch_assoc();
                    ?>
                        <img src="<?php echo $profile_image_data["path"]; ?>" style="height: 40px;margin-left: 60px;" />
                    <?php
                    } else {
                    ?>
                        <img src="resource/new_user.svg" style="height: 40px;margin-left: 50px;" />
                    <?php
                    }
                    ?>
                </td>
                <td><?php echo ($selected_data["email"]); ?></td>
                <td><?php echo $selected_data["mobile"]; ?></td>
                <td> <?php
                        $splitDate = explode(" ", $selected_data["joined_date"]);
                        ?>
                    <span class=" "><?php echo $splitDate[0]; ?></span>
                </td>
                <?php
                if ($selected_data["status_id"] == 1) {
                ?>
                    <td class="status">Active</td>
                <?php
                } else {
                ?>
                    <td class="status-red">Deactive</td>
                <?php
                }
                ?>
                <td class="actions">
                        <?php
                        if ($selected_data["status_id"] == 1) {
                        ?>
                            <button onclick="blockUser('<?php echo $selected_data['email']; ?>');">🔒</button>
                        <?php
                        } else {
                        ?>
                            <button onclick="blockUser('<?php echo $selected_data['email']; ?>');">🔑</button>
                        <?php
                        }
                        ?>
                            

                        </td>
            </tr>
        <?php

        }
        ?>
    <?php

    } else {
        echo ("Email does not exist");
    ?>

    <?php

    }
    ?>


</tbody>
</table>
</div>
</div>
<script src="bootstrap.bundle.js"></script>
<script src="script.js"></script>
</body>

</html>