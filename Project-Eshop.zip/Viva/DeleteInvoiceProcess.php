<?php

session_start();
include "connection.php";

if (isset($_SESSION["u"])) {

    $email = $_SESSION["u"]["email"];
    if (isset($_GET["id"])) {
   $id=$_GET["id"];

        Database::iud("UPDATE `invoice`
                        SET status = '1' 
                    WHERE invoice_id ='" . $id . "'");
        echo ("Successfully deleted");


    }else if (isset($_GET["idd"])) {
     $id = $_GET["idd"];

        Database::iud("UPDATE `invoice_multiple`
                        SET status = '1' 
                    WHERE order_id ='" . $id . "'");
        echo ("Successfully deleted");
    }
}
