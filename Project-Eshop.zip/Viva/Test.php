<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loading Screen Example</title>
    <style>
        /* Style for the loading overlay */
        #loadingOverlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            display: none;
            /* Hidden by default */
            justify-content: center;
            align-items: center;
        }

        /* Style for the spinner */
        .spinner {
            border: 16px solid #f3f3f3;
            border-radius: 50%;
            border-top: 16px solid #3498db;
            width: 120px;
            height: 120px;
            animation: spin 2s linear infinite;
        }

        @keyframes spin {
            0% {
                transform: rotate(0deg);
            }

            100% {
                transform: rotate(360deg);
            }
        }
    </style>
</head>

<body>

    <div class="col-6">
        <label class="form-label">Gender</label>
        <select class="form-select" id="g">
            <?php

            require "connection.php";

            $rs = Database::search("SELECT * FROM gender");
            $n = $rs->num_rows;

            for ($x = 0; $x < $n; $x++) {
                $d = $rs->fetch_assoc();

            ?>

                <option value="<?php echo $d["id"]; ?>"><?php echo $d["gender_name"]; ?></option>

            <?php

            }

            ?>

</body>

</html>
<script></script>