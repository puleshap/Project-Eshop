<?php

require "connection.php";

if (isset($_GET["c"])) {
    $brand_id = $_GET["c"];
    if ($brand_id == 0) {
?>
        <option value="0">Select Model </option><?php


                                            }
                                        }


                                        $brand_rs = Database::search("SELECT * FROM `brand_has_model` INNER JOIN `model` ON model.id=brand_has_model.model_id
AND brand_id ='$brand_id'");
                                        $brand_num = $brand_rs->num_rows;

                                        if ($brand_num > 0) {
                                                ?><option value="0">Select Model </option><?php

                                                    for ($x = 0; $x < $brand_num; $x++) {

                                                        $brand_data = $brand_rs->fetch_assoc();

                                                    ?>

        <option value="<?php echo $brand_data["id"]; ?>"><?php echo $brand_data["model_name"]; ?></option>

    <?php

                                                    }
                                                } else {
    ?>
    <option value="0">Models have not yet been added </option><?php
                                                                ?>


<?php

                                                }


?>