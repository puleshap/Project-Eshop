<?php

require "connection.php";

?>

<link rel="stylesheet" href="bootstrap.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="style.css" />
<link rel="stylesheet" href="styles/Admin_User_Panel.css" />

<div class="col-12 bg-dark text-center">
        <label class="form-label text-primary fw-bold fs-1">M o d e l  &nbsp; &nbsp; M a n a g e m e n t &nbsp; &nbsp; P a n e l</label>
</div>
<div class="container">
<br>
    <div class="search-bar">

        <input type="text" id="searchUsers" placeholder="Search Model" class=" rounded rounded-3">
        <button id="searchButton " class=" rounded rounded-3 border border-3" onclick="SearchModelPanel();">🔍</button>

        <button class="btn btn-info col-3 col-lg-3 rounded border " style="margin-left: 40px; font-weight: bold;" onclick="Modalview();"> Add New Model ➕</button>

    </div>
    <br>
    <div class="table-wrapper">
        <table id="userTable">
            <thead>
                <tr>
                    <th class="bg-secondary fw-light text-center">ID</th>
                    <th class="bg-secondary fw-light text-center">Model Name</th>
                    <th class="bg-secondary fw-light text-center">Brand</th>

                </tr>
            </thead>
            <tbody id="tbody">
                <?php

                $query = "SELECT brand.id AS brand_idd, 
    model.id AS model_idd,
    brand.*,
    model.*,
    brand_has_model.* FROM `brand`,`brand_has_model`,`model` WHERE
brand.id = brand_has_model.brand_id AND
model.id = brand_has_model.model_id";
                $pageno;

                if (isset($_GET["page"])) {
                    $pageno = $_GET["page"];
                } else {
                    $pageno = 1;
                }

                $user_rs = Database::search($query);
                $user_num = $user_rs->num_rows;

                $selected_rs = Database::search($query);

                $selected_num = $selected_rs->num_rows;

                for ($x = 0; $x < $selected_num; $x++) {
                    $selected_data = $selected_rs->fetch_assoc();

                ?>

                    <tr>
                        <td class="text-center"><?php echo ($selected_data["model_idd"]); ?></td>
                        <td class="text-center"><?php echo $selected_data["model_name"]; ?></td>


                        <td class="text-center"><?php echo $selected_data["brand_name"]; ?></td>


                    </tr>

                <?php

                }
                ?>

            </tbody>
        </table>
    </div>
</div>
<div class="modal" tabindex="-1" id="userMsgModal">
    <div class="modal-dialog">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title">Forgot Password</h5>
                <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <div class="row g-3">

                    <div class="col-12 mt-2">
                        <div class="row">
                            <div class="col-12">
                                <label class="form-label fw-bold  " style="font-size: 20px;">Select Product Brand</label>
                            </div>

                            <div class="col-12">
                                <select class="form-select  text-centertext-white" style="background-color:#002d5b;" id="brand" >
                                    <option value="0">Select Brand</option>
                                    <?php
                                    $category_rs = Database::search("SELECT * FROM `brand` ");
                                    $category_num = $category_rs->num_rows;

                                    for ($x = 0; $x < $category_num; $x++) {
                                        $category_data = $category_rs->fetch_assoc();
                                    ?>
                                        <option value="<?php echo $category_data["id"]; ?>" >
                                            <?php echo $category_data["brand_name"]; ?>
                                        </option>
                                    <?php
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="col-12">
                        <label class="form-label">Input Model Name :</label>
                        <input type="text" class="form-control text-white" style="background-color:#002d5b;" id="nm" />
                    </div>
                    <div class="col-12">
                        <label class="form-label">Input Admin Password :</label>
                        <input type="text" class="form-control text-white" style="background-color:#002d5b;" id="pw" />
                    </div>

                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary"    onclick="AddModel();">Create Brand</button>
            </div>
        </div>
    </div>
</div>
</div>

<script src="bootstrap.bundle.js"></script>
<script src="script.js"></script>
<script src="AdminScript.js"></script>