<!DOCTYPE html>

<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>My Products | GamerShop</title>
    <link rel="stylesheet" href="styles/pagination.css">
    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css" />
    <link rel="stylesheet" href="style.css" />

    <link rel="icon" href="resource/logo.png" />

</head>



<body class=" ">
    <?php



    include "header.php";
    include "connection.php";
    if (isset($_SESSION["u"])) {

        $email = $_SESSION["u"]["email"];
        $pageno;

    ?>

        <hr>
        <div class="container-fluid">
            <div class="row">

                <!-- header -->
                <header>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="home.php">Home</a></li>
                            <li class="breadcrumb-item active text-white-50" aria-current="page">My Products </li>
                        </ol>
                    </nav>
                    <h1>My Products </h1>
                </header>
                <!-- header -->
                <!-- body -->
                <div class="col-12">
                    <div class="row sidebar">
                        <button class="btn  btn-success fw-bold" onclick="window.location='addProduct.php'">
                                Add New Product to your Products</button>
                        <!-- filter -->
                        <div class="col-11 col-lg-2 mx-3 my-3 bg-black border border-white rounded">

                            <div class="row">

                                <div class="col-12 mt-3 fs-5">
                                    <div class="row">

                                        <div class="col-12">
                                            <label class="form-label fw-bold fs-3">Sort Products</label>
                                        </div>
                                        <div class="col-11">
                                            <div class="row">
                                                <div class="col-10">
                                                    <input type="text" placeholder="Search..." class="form-control" id="s" />
                                                </div>
                                                <div class="col-1 p-1">
                                                    <label class="form-label"><i class="bi bi-search fs-5"></i></label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12 mt-3">
                                            <label class="form-label fw-bold">By condition</label>
                                        </div>
                                        <div class="col-12">
                                            <hr style="width: 80%;" />
                                        </div>

                                        <div class="col-12">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="r3" id="b">
                                                <label class="form-check-label" for="b">
                                                    Brandnew
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="r3" id="u">
                                                <label class="form-check-label" for="u">
                                                    Used
                                                </label>
                                            </div>
                                        </div>


                                        <div class="col-12 mt-3">
                                            <label class="form-label fw-bold">By quantity</label>
                                        </div>
                                        <div class="col-12">
                                            <hr style="width: 80%;" />
                                        </div>

                                        <div class="col-12">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="r2" id="h">
                                                <label class="form-check-label" for="h">
                                                    High to low
                                                </label>
                                            </div>
                                        </div>

                                        <div class="col-12">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="r2" id="l">
                                                <label class="form-check-label" for="l">
                                                    Low to high
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <br>
                                            <label class="form-label fw-bold">Active Time</label>
                                        </div>
                                        <div class="col-12">
                                            <hr style="width: 80%;" />
                                        </div>
                                        <div class="col-12">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="r1" id="n">
                                                <label class="form-check-label" for="n">
                                                    Newest to oldest
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="r1" id="o">
                                                <label class="form-check-label" for="o">
                                                    Oldest to newest
                                                </label>
                                            </div>
                                        </div>


                                        <div class="col-12 text-center mt-3 mb-3">
                                            <div class="row g-2">
                                                <div class="col-12 col-lg-6 d-grid">
                                                    <button class="btn btn-success fw-bold sort" onclick="sort1(0);">Sort</button>
                                                </div>
                                                <div class="col-12 col-lg-6 d-grid">
                                                    <button class="btn btn-warning  fw-bold clear" onclick="clearSort();">Clear</button>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- filter -->
                        <!-- product -->
                        <div class="col-12 col-lg-9 mt-3 mb-3 bg-black products ">
                            <div class="row" id="sort">
                                <div class="offset-1 col-10 text-center">
                                    <div class="row justify-content-center">

                                        <?php

                                        if (isset($_GET["page"])) {
                                            $pageno = $_GET["page"];
                                        } else {
                                            $pageno = 1;
                                        }

                                        $product_rs = Database::search("SELECT * FROM `product` WHERE `user_email`='" . $email . "' ");
                                        $product_num = $product_rs->num_rows;

                                        $results_per_page = 4;
                                        $number_of_pages = ceil($product_num / $results_per_page);

                                        $page_results = ($pageno - 1) * $results_per_page;
                                        $selected_rs = Database::search("SELECT * FROM `product` WHERE `user_email`='" . $email . "' 
                                                    LIMIT " . $results_per_page . " OFFSET " . $page_results . "");

                                        $selected_num = $selected_rs->num_rows;
                                        for ($x = 0; $x < $selected_num; $x++) {
                                            $selected_data = $selected_rs->fetch_assoc();
                                        ?>
                                            <?php if ($selected_data['status_id'] !== 3) {
                                            ?>
                                                <!-- card -->
                                                <div class="card mb-3 mt-3 col-12 col-lg-5 product-item mx-1">
                                                    <div class="row">
                                                        <div class="col-md-4 mt-2">

                                                            <?php
                                                            $product_image_rs = Database::search("SELECT * FROM `product_image` WHERE `product_id`='" . $selected_data["id"] . "'");
                                                            $product_image_data = $product_image_rs->fetch_assoc();
                                                            ?>
                                                            <img src="<?php echo $product_image_data["img_path"]; ?>" class="img-fluid rounded-start img-thumbnail" />
                                                        </div>
                                                        <div class="col-md-8">

                                                            <div class="card-body ">

                                                                <h5 class="card-title  ">Title : <?php echo $selected_data["title"]; ?></h5>
                                                                <div class="ad-price">

                                                                    <?php
                                                                    if ($selected_data['condition_id'] == 1) {
                                                                    ?>
                                                                        <span class="badge rounded-pill text-info" style="font-size: 15px;">Condition : New</span>
                                                                    <?php
                                                                    } else {
                                                                    ?>
                                                                        <span class="badge rounded-pill text-warning" style="font-size: 15px;">Condition : Used</span>
                                                                    <?php
                                                                    }
                                                                    ?>
                                                                </div>
                                                                <?php if($selected_data['updated_price'] == ""){ ?>
                                                                <span class="card-text ">Price : Rs. <?php echo $selected_data["price"]; ?> .00</span><br />
                                                                <?php }else{?>
                                                                    <span class="card-text ">Price : Rs. <?php echo $selected_data["updated_price"]; ?> .00</span><br />
                                                                    <?php }?>
                                                                <span class="card-text  ">Quantity : <?php echo $selected_data["qty"]; ?> Items left</span>
                                                                <div class="form-check form-switch">
                                                                    <?php if ($selected_data["status_id"] == 3) { ?>
                                                                        <label class="form-check-label fs-5 " style="margin-right: 40px; color: #f04747;">Product Blocked by Admin</label>
                                                                    <?php } else { ?>
                                                                        <input class="form-check-input" type="checkbox" role="switch" id="toggle<?php echo $selected_data["id"]; ?>" onchange="changeStatus(<?php echo $selected_data['id']; ?>);" <?php if ($selected_data["status_id"] == 2) { ?> checked <?php } ?> />
                                                                        <label class="form-check-label  text-info" for="toggle<?php echo $selected_data["id"]; ?>">
                                                                            <?php if ($selected_data["status_id"] == 1) { ?>
                                                                                <label class="form-check-label  " style="margin-right: 20px; color: #43b581;">Product Active</label>
                                                                            <?php } elseif ($selected_data["status_id"] == 2) { ?>
                                                                                <label class="form-check-label  " style="color: #f04747;"> Product Deactive</label>
                                                                        <?php }
                                                                        } ?>
                                                                        </label>
                                                                </div>
                                                                <div class="row">
                                                                    <div class="col-12">
                                                                        <div class="row g-1">
                                                                            <div class="col-12 d-grid">
                                                                                <a href='<?php echo "singleProductView.php?id=" . ($selected_data["id"]); ?>'><button class="btn btn-success  mt-2">
                                                                                        View Product
                                                                                    </button>
                                                                                </a>
                                                                                <button class="btn update  mt-2" onclick="sendid(<?php echo $selected_data['id']; ?>);">
                                                                                    Update
                                                                                </button>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- card -->
                                            <?php   } else { ?>
                                                <div class="card mb-3 mt-3 col-12 col-lg-5 product-item mx-1 bg-danger">
                                                    <div class="row">
                                                        <div class="col-md-4 mt-2">

                                                            <?php
                                                            $product_image_rs = Database::search("SELECT * FROM `product_image` WHERE `product_id`='" . $selected_data["id"] . "'");
                                                            $product_image_data = $product_image_rs->fetch_assoc();
                                                            ?>
                                                            <img src="<?php echo $product_image_data["img_path"]; ?>" class="img-fluid rounded-start img-thumbnail" />
                                                        </div>
                                                        <div class="col-md-8">
                                                            <label class="form-check-label text-dark fw-bold fs-3 "> Product Blocked by Admin</label>
                                                            <div class="card-body ">

                                                                <h5 class="card-title  ">Title : <?php echo $selected_data["title"]; ?></h5>
                                                                <div class="ad-price">

                                                                    <?php
                                                                    if ($selected_data['condition_id'] == 1) {
                                                                    ?>
                                                                        <span class="badge rounded-pill text-info" style="font-size: 15px;">Condition : New</span>
                                                                    <?php
                                                                    } else {
                                                                    ?>
                                                                        <span class="badge rounded-pill text-warning" style="font-size: 15px;">Condition : Used</span>
                                                                    <?php
                                                                    }
                                                                    ?>
                                                                </div><?php if($selected_data['updated_price'] == ""){ ?>
                                                                <span class="card-text ">Price : Rs. <?php echo $selected_data["price"]; ?> .00</span><br />
                                                                <?php }else{?>
                                                                    <span class="card-text ">Price : Rs. <?php echo $selected_data["updated_price"]; ?> .00</span><br />
                                                                    <?php }?>
                                                                <span class="card-text  ">Quantity : <?php echo $selected_data["qty"]; ?> Items left</span>


                                                                <div class="row">
                                                                    <div class="col-12">
                                                                        <div class="row g-1">
                                                                            <div class="col-12 d-grid">
                                                                                <a href='<?php echo "singleProductView.php?id=" . ($selected_data["id"]); ?>'><button class="btn btn-success  mt-2">
                                                                                        View Product
                                                                                    </button>
                                                                                </a>
                                                                                <button class="btn update  mt-2" onclick="sendid(<?php echo $selected_data['id']; ?>);">
                                                                                    Update
                                                                                </button>

                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                            <?php } ?>
                                        <?php
                                        }

                                        ?>


                                    </div>
                                </div>
                                <div class="offset-2 offset-lg-3 col-8 col-lg-6 text-center  mb-3">
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination pagination-lg  justify-content-center">
                                            <li class="page-item">
                                                <a class="page-link bg-dark" href="
                                        <?php if ($pageno <= 1) {
                                            echo ("#");
                                        } else {
                                            echo "?page=" . ($pageno - 1);
                                        } ?>
                                        " aria-label="Previous">
                                                    <span aria-hidden="true">&laquo;</span>
                                                </a>
                                            </li>

                                            <?php
                                            for ($x = 1; $x <= $number_of_pages; $x++) {
                                                if ($x == $pageno) {
                                            ?>
                                                    <li class="page-item active">
                                                        <a class="page-link " style="background-color: #002d5b;" href="<?php echo "?page=" . ($x); ?>"><?php echo $x; ?></a>
                                                    </li>
                                                <?php
                                                } else {
                                                ?>
                                                    <li class="page-item">
                                                        <a class="page-link bg-secondary text-white" href="<?php echo "?page=" . ($x); ?>"><?php echo $x; ?></a>
                                                    </li>
                                            <?php
                                                }
                                            }
                                            ?>

                                            <li class="page-item">
                                                <a class="page-link bg-dark" href="
                                        <?php if ($pageno >= $number_of_pages) {
                                            echo ("#");
                                        } else {
                                            echo "?page=" . ($pageno + 1);
                                        } ?>
                                        " aria-label="Next">
                                                    <span aria-hidden="true">&raquo;</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                        </div>
                        <!-- product -->
                    </div>
                </div>
                <!-- body -->

                <?php include "footer.php"; ?>

            </div>
        </div>
        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>
</body>
<?php  } else { ?>


<?php
        header("Location:home.php");
    }
?>

</html>
<?php



?>
<style>
    body {
        font-family: 'Arial', sans-serif;
        color: #ffffff;
        background-color: #2c2f33;
        margin: 0;
        padding: 0;
    }

    .container {
        display: flex;
        justify-content: space-between;
        padding: 20px;
    }

    .products {
        flex: 3;
        padding: 10px;
    }

    .sidebar {
        flex: 1;
        padding: 20px;
        background-color: #23272a;
        border-radius: 8px;
    }

    .sort-products {
        border: 1px solid #99aab5;
        padding: 20px;
        border-radius: 8px;
        background-color: #2c2f33;
    }

    .sort-products input[type="search"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 20px;
        border-radius: 4px;
        border: 1px solid #99aab5;
        background-color: #3b3f45;
        color: #ffffff;
    }

    .sort-products label {
        display: block;
        margin: 10px 0 5px;
        font-weight: bold;
    }

    .sort-products input[type="radio"] {
        margin-right: 10px;
    }



    .product-item {
        margin-bottom: 20px;
        padding: 20px;
        background-color: #002d5b;
        border-radius: 8px;
        display: flex;
        flex-direction: column;
        align-items: center;
        text-align: center;
    }

    .product-item img {
        max-width: 100px;
        border-radius: 8px;
        margin-bottom: 10px;
    }

    .product-item .update {
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        background-color: #28a745;
        color: #ffffff;
        cursor: pointer;
    }

    .product-item .update:hover {
        background-color: #368b6a;
    }

    .pagination {
        display: flex;
        justify-content: center;
        padding: 20px;
    }

    .pagination button {
        padding: 10px 15px;
        border: none;
        border-radius: 4px;
        background-color: #7289da;
        color: #ffffff;
        cursor: pointer;
        margin: 0 5px;
    }

    .pagination button:hover {
        background-color: #5b6eae;
    }
</style>