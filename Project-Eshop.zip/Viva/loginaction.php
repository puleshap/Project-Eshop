<?php

$u = $_GET['U'];
$u = $_GET['P'];
echo ($u);


?>