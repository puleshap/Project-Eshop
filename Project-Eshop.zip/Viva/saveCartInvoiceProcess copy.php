<?php

session_start();
include "connection.php";

if(isset($_SESSION["u"])){

    $order_id = $_POST["oid"];
    $mail = $_SESSION["u"]["email"];
   
    $amount = $_POST["q"];
    $qty = $_POST["o"];
    $n = $_POST["n"];
    $shipping = $_POST["s"];

    $productIdsJSON = $_POST['itemNames'];
   
    $productIds = json_decode($productIdsJSON, true); // Decode JSON to PHP array
    
    // Check if $productIds is an array before using it in foreach
    if (is_array($productIds)) {
        foreach ($productIds as $productId) {

            $product_rs = Database::search("SELECT * FROM `product` WHERE `id`='".$productId."'");
            $product_data = $product_rs->fetch_assoc();
        
            $current_qty = $product_data["qty"];
            $new_qty = $current_qty - $qty;
        
            Database::iud("UPDATE `product` SET `qty`='".$new_qty."' WHERE `id`='".$productId."'");
        
            $d = new DateTime();
            $tz = new DateTimeZone("Asia/Colombo");
            $d->setTimezone($tz);
            $date = $d->format("Y-m-d H:i:s");
        

        }
    } else {
        echo "Error: Invalid product IDs data";
    }
    Database::iud("INSERT INTO `invoice_multiple`(`order_id`,`product_titles`,`qty`,`total`,`shipping`,`user_email`,`date`)
     VALUES ('" . $order_id . "','" . $n . "','$qty','$amount','$shipping','$mail','$date')");
   
    Database::iud("INSERT INTO `invoice`(`order_id`,`date`,`total`,`qty`,`status`,`product_id`,`user_email`) 
    VALUES ('".$order_id."','".$date."','".$amount."','".$qty."','0','1','".$mail."')");
    
    echo ("success");

}

?>