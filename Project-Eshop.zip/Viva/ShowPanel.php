<head>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<?php
session_start();

include "connection.php";
$num = $_GET["num"];
if (isset($num)) {
    $today = date("Y-m-d");
    $thismonth = date("m");
    $thisyear = date("Y");

    $a = "0";
    $b = "0";
    $c = "0";
    $e = "0";
    $f = "0";
    $g = "0";
    $h = "0";
    $i = "0";
    $j = "0";
    $earning_text;
    $selling_text;
    $member_text;
    $Sold_text;

    $invoice_rs = Database::search("SELECT * FROM `invoice`");
    $invoice_num = $invoice_rs->num_rows;

    for ($x = 0; $x < $invoice_num; $x++) {
        $invoice_data = $invoice_rs->fetch_assoc();

        $f = $f + $invoice_data["qty"]; 
        $h = $h + $invoice_data["total"];

        $d = $invoice_data["date"];
        $splitDate = explode(" ", $d); 
        $pdate = $splitDate["0"]; 

        if ($pdate == $today) {
            $a = $a + $invoice_data["total"];
            $c = $c + $invoice_data["qty"];
        }

        $splitMonth = explode("-", $pdate);
        $pyear = $splitMonth["0"]; 
        $pmonth = $splitMonth["1"]; 

        if ($pyear == $thisyear) {
            if ($pmonth == $thismonth) {
                $b = $b + $invoice_data["total"];
                $e = $e + $invoice_data["qty"];
            }
            $g = $g + $invoice_data["total"];
            $i = $i + $invoice_data["qty"];
        }
    }









    $earnings = "0";
    $sellings = "0";
    $members = "0";
    $query1;
    $query2;

    if ($num == 1) {

        $earning_text = "Todays Earning";
        $selling_text = "Total Items Sold Today";
        $member_text = "New Members joined today";
        $Sold_text = "Most Sold Item Today";
        $earnings = $a;
        $sellings = $c;
        $query1 = "SELECT COUNT(*) AS users FROM user WHERE DATE(joined_date) = CURDATE();";
        $query2 = "SELECT `product_id`,COUNT(`product_id`) AS `value_occurence` FROM `invoice` 
                    WHERE DATE(date) = CURDATE();";
    } elseif ($num == 2) {

        $earning_text = "This Months Earning";
        $selling_text = "Total Items Sold This Month";
        $member_text = "New Members joined this Month";
        $Sold_text = "Most Sold Item this Month";
        $earnings = $b;
        $sellings = $e;
        $query1 = "SELECT COUNT(*) AS users 
        FROM user WHERE YEAR(joined_date) = YEAR(CURDATE()) AND MONTH(joined_date) = MONTH(CURDATE());";
        $query2 = "SELECT `product_id`,COUNT(`product_id`) AS `value_occurence` FROM `invoice`
         WHERE YEAR(date) = YEAR(CURDATE()) AND MONTH(date) = MONTH(CURDATE())
        GROUP BY `product_id` ORDER BY `value_occurence` DESC LIMIT 1";
    } elseif ($num == 3) {

        $earning_text = "This Years Earning";
        $selling_text = "Total Items Sold This Year";
        $member_text = "New Members joined this Year";
        $Sold_text = "Most Sold Item this Year";
        $earnings = $g;
        $sellings = $i;
        $query1 = "SELECT COUNT(*) AS users FROM user WHERE YEAR(joined_date) = YEAR(CURDATE());";

        $query2 = "SELECT `product_id`,COUNT(`product_id`) AS `value_occurence` FROM `invoice` 
        WHERE YEAR(date) = YEAR(CURDATE())
        GROUP BY `product_id` ORDER BY `value_occurence` DESC LIMIT 1";
    } elseif ($num == 4) {

        $earning_text = "All Earnings";
        $selling_text = "All Items Sold";
        $member_text = "All members joined";
        $Sold_text = "Most Sold Item of All Time";
        $earnings = $h;
        $sellings = $f;
        $query1 = "SELECT COUNT(*) AS users FROM user;";
        $query2 = "SELECT `product_id`,COUNT(`product_id`) AS `value_occurence` FROM `invoice` 
        GROUP BY `product_id` ORDER BY `value_occurence` DESC LIMIT 1";
    }

    $user_rs = Database::search($query1);
    $users_data = $user_rs->fetch_assoc();


?>


    <div class="col-6 col-lg-4 px-1 shadow">
        <div class="row g-1">
            <div class="col-12 bg-primary text-white text-center rounded" style="height: 100px;">
                <br />
                <span class="fs-4 fw-bold"><?php echo ($earning_text); ?></span>


                <br />
                <span class="fs-5">Rs. <?php echo $earnings; ?> .00</span>
            </div>
        </div>
    </div>



    <div class="col-6 col-lg-4 px-1">
        <div class="row g-1">
            <div class="col-12 bg-dark text-white text-center rounded" style="height: 100px;">
                <br />
                <span class="fs-4 fw-bold"><?php echo ($selling_text); ?></span>
                <br />
                <span class="fs-5"><?php echo $sellings; ?> Items</span>
            </div>
        </div>
    </div>





    <div class="col-6 col-lg-4 px-1 shadow">
        <div class="row g-1">
            <div class="col-12 bg-danger text-white text-center rounded" style="height: 100px;">
                <br />
                <span class="fs-4 fw-bold"><?php echo ($member_text); ?></span>
                <br />
                <span class="fs-5"><?php echo $users_data['users']; ?> Members</span>
            </div>
        </div>
    </div>



    <div class="offset-1 offset-lg-4 col-10 col-lg-4 my-3 rounded bg-body">
        <div class="row g-1">
            <div class="col-12 text-center">
                <label class="form-label fs-4 fw-bold text-decoration-underline"><?php echo ($Sold_text); ?></label>
            </div>

            <?php

            $freq_rs = Database::search($query2);

            $freq_num = $freq_rs->num_rows;
            $freq_data = $freq_rs->fetch_assoc();

            if ($freq_data['value_occurence'] > 0) {



                $product_rs = Database::search("SELECT * FROM `product` WHERE `id`='" . $freq_data["product_id"] . "'");
                $product_data = $product_rs->fetch_assoc();

                $image_rs = Database::search("SELECT * FROM `product_image` WHERE `product_id`='" . $freq_data["product_id"] . "'");
                $image_data = $image_rs->fetch_assoc();

                $qty_rs = Database::search("SELECT SUM(`qty`) AS `qty_total` FROM `invoice` WHERE 
                                    `product_id`='" . $freq_data["product_id"] . "' AND `date` LIKE '%" . $today . "%'");
                $qty_data = $qty_rs->fetch_assoc();

            ?>
                <div class="col-12 text-center ">
                    <img src="<?php echo $image_data["img_path"]; ?>" class="img-fluid rounded-top" style="height: 100px; width: 100px;" />
                </div>
                <div class="col-12 text-center my-3">
                    <span class="fs-5 fw-bold">Product Title : <?php echo $product_data["title"]; ?></span><br />
                    <span class="fs-5 fw-bold">Seller : <?php echo $product_data["user_email"]; ?></span><br />
                    <span class="fs-6">Sold Amount of Items : <?php echo $qty_data["qty_total"]; ?> items</span><br />
                    <span class="fs-6">Item Price : Rs. <?php echo $qty_data["qty_total"] * $product_data["price"]; ?> .00</span>
                </div>
            <?php

            } else {
            ?>
                <!-- empty product -->
                <div class="col-12 text-center ">
                    <img src="resource/empty.svg" class="img-fluid rounded-top" style="height: 100px;" />
                </div>
                <div class="col-12 text-center my-3">
                    <span class="fs-5 fw-bold">No Items Sold Today Yet</span><br />
                    <span class="fs-6"> 00 items</span><br />
                    <span class="fs-6">Rs.00 .00</span>
                </div>
                <!-- empty product -->
            <?php
            }

            ?>


        </div>

    </div>




<?php


}
?>