<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Products</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        /* Add the custom CSS here */
    </style>
</head>
<style>body {
    background-color: #f0f2f5; /* Light background color */
    font-family: 'Arial', sans-serif; /* Modern font */
}

header {
    background-color: #343a40; /* Dark header background */
    color: white;
    padding: 10px 0;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow */
}

.sidebar {
    background-color: #2c2c2c; /* Contrasting sidebar background */
    color: white;
    padding: 20px;
    border-radius: 10px;
}

.sidebar h4, .sidebar button {
    margin-bottom: 15px;
}

.product-card {
    background-color: white;
    border-radius: 10px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Subtle shadow */
    padding: 20px;
    margin-bottom: 20px;
    transition: transform 0.2s;
}

.product-card:hover {
    transform: translateY(-5px); /* Lift on hover */
}

.product-card img {
    border-radius: 10px;
    width: 100%; /* Ensure images are responsive */
    max-height: 150px;
    object-fit: cover; /* Maintain aspect ratio */
}

.product-card .btn {
    background-color: #28a745; /* Vibrant button color */
    border: none;
    color: white;
    transition: background-color 0.3s;
}

.product-card .btn:hover {
    background-color: #218838; /* Darker on hover */
}

.pagination .page-item .page-link {
    color: #6c757d;
    background-color: white;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 5px;
}

.pagination .page-item.active .page-link {
    background-color: #343a40;
    color: white;
}

.pagination .page-item .page-link:hover {
    background-color: #6c757d;
    color: white;
}
</style>
<body>
    <header class="text-center">
        <h1>My Products</h1>
    </header>

    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-md-3 sidebar">
                <h4>Sort Products</h4>
                <input type="text" class="form-control mb-3" placeholder="Search...">
                <h5>By condition</h5>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="condition" id="new" value="new">
                    <label class="form-check-label" for="new">Brand New</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="condition" id="used" value="used">
                    <label class="form-check-label" for="used">Used</label>
                </div>
                <h5 class="mt-3">By quantity</h5>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="quantity" id="highToLow" value="highToLow">
                    <label class="form-check-label" for="highToLow">High to Low</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="quantity" id="lowToHigh" value="lowToHigh">
                    <label class="form-check-label" for="lowToHigh">Low to High</label>
                </div>
                <h5 class="mt-3">Active Time</h5>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="time" id="newest" value="newest">
                    <label class="form-check-label" for="newest">Newest to oldest</label>
                </div>
                <div class="form-check">
                    <input class="form-check-input" type="radio" name="time" id="oldest" value="oldest">
                    <label class="form-check-label" for="oldest">Oldest to newest</label>
                </div>
                <button class="btn btn-success mt-3">Sort</button>
                <button class="btn btn-warning mt-3">Clear</button>
            </div>
            <div class="col-md-9">
                <div class="row">
                    <div class="col-md-4">
                        <div class="product-card">
                            <img src="path/to/image.jpg" alt="Product Image">
                            <h5 class="mt-2">Name: test</h5>
                            <p>Condition: Used</p>
                            <p>Price: Rs. 123.00</p>
                            <p>Quantity: 0 items left</p>
                            <button class="btn btn-success">Update</button>
                        </div>
                    </div>
                    <!-- Repeat the product card for other products -->
                </div>
                <div class="pagination-container text-center mt-4">
                    <nav aria-label="Page navigation example">
                        <ul class="pagination pagination-lg justify-content-center">
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Previous">
                                    <span aria-hidden="true">&laquo;</span>
                                </a>
                            </li>
                            <li class="page-item active">
                                <a class="page-link" href="#">1</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#">2</a>
                            </li>
                            <li class="page-item">
                                <a class="page-link" href="#" aria-label="Next">
                                    <span aria-hidden="true">&raquo;</span>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
