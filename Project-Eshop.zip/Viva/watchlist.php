<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>GamerShop | Watchlist</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="bootstrap1.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css" />

    <link rel="icon" href="resource/logo.png" />
</head>

<body style="  background: linear-gradient(to bottom, #002d5b, #000000);color: #ffffff;">
    <?php include "header.php";
    include "connection.php";
    if (isset($_SESSION["u"])) {



    ?>
    <hr>

     <div class="container-fluid">
     <div class="row">
        <div class="">
            <header>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="home.php">Home</a></li>
                        <li class="breadcrumb-item active text-white-50" aria-current="page">WishList</li>
                    </ol>
                </nav>
                <h1>My Wishlist &hearts;</h1>
            </header>
            <hr>
            <?php
            $watchlist_rs = Database::search("SELECT * FROM `watchlist` INNER JOIN `product` ON 
                         watchlist.product_id=product.id   INNER JOIN `condition` ON 
                         product.condition_id=condition.id INNER JOIN `user` ON 
                         product.user_email=user.email WHERE watchlist.user_email='" . $_SESSION["u"]["email"] . "'");

            $watchlist_num = $watchlist_rs->num_rows;
            ?>
            <?php

            if ($watchlist_num == 0) {
            ?>
                <!-- empty view -->
                <div class="col-12 ">
                    <div class="row">
                        <div class="col-12 emptyView "></div>
                        <div class="col-12 text-center">
                            <label class="form-label fs-1 fw-bold">You have no items in your Watchlist
                                yet.</label>
                        </div>
                        <div class="offset-lg-4 col-12 col-lg-4 d-grid mb-3">
                            <a href="home.php" class="btn btn-warning fs-3 fw-bold">Start Shopping</a>
                        </div>
                    </div>
                </div>
                <!-- empty view -->
            <?php
            } else {
            ?>
                <table class="wishlist-table text-black "  >
                    <thead  style="background-color:#002d5b ;">
                        <tr >
                            <th>Product name</th>
                            <th>Condition</th>
                            <th>Unit price</th>
                            <th>Stock status</th>
                            <th>Seller</th>
                            <th class="text-end">Actions</th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        for ($x = 0; $x < $watchlist_num; $x++) {
                            $watchlist_data = $watchlist_rs->fetch_assoc();
                            $list_id = $watchlist_data["product_id"];

                            $img_rs = Database::search("SELECT * FROM `product_image` WHERE `product_id`='" . $watchlist_data["product_id"] . "'");
                            $img_data = $img_rs->fetch_assoc();
                        ?>
                            <tr>
                                <td>
                                    <img src="<?php echo $img_data["img_path"]; ?>" alt="Product Image" class="product-image">
                                    <span><?php echo $watchlist_data["title"]; ?></span>
                                </td>
                                <td>
                                    <?php
                                    if ($watchlist_data['condition_id'] == 1) {
                                    ?>
                                        <span class="badge rounded-pill text-info" style="font-size: 15px;">New</span>
                                    <?php
                                    } else {
                                    ?>
                                        <span class="badge rounded-pill text-warning" style="font-size: 15px;">Used</span>
                                    <?php
                                    }
                                    ?>
                                </td>
                                <?php
                                if ($watchlist_data["updated_price"] == "") {
                                ?> <td>
                                        <span>Rs. <?php echo $watchlist_data["price"]; ?> .00</span>
                                    </td>


                                <?php
                                } else {
                                ?>
                                    <td>
                                        
                                        <span class="original-price">Rs. <?php echo $watchlist_data["price"]; ?> .00</span>
                                        <span class="discounted-price">Rs. <?php echo $watchlist_data["updated_price"]; ?> .00</span>
                                       
                                    </td>
                                <?php
                                }
                                ?>
                                <td><?php echo $watchlist_data["qty"]; ?> Items available</td>
                                <td><?php echo $watchlist_data["fname"] . " " . $watchlist_data["lname"]; ?></td>
                                <td> <a href='<?php echo "singleProductView.php?id=" . ($watchlist_data["product_id"]); ?>' class="col-12 btn btn-outline-success">
                                        View Item
                                    </a> </td>
                                <td><a href="#" class="col-12 btn btn-outline-danger mt-2" onclick='removeFromWatchlist(<?php echo ($watchlist_data["product_id"]); ?>);'>
                                        Remove
                                    </a> </td>
                            </tr>

                        <?php
                        }

                        ?>
                    </tbody>
                </table>
        </div>
        
    <?php
            }
            include "footer.php";
    ?>
<?php
    } ?>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script src="bootstrap.bundle.js"></script>
<script src="script.js"></script>

</body>

</html>