<?php

include "connection.php";

if(isset($_GET["qty"]) & isset($_GET["id"])){

    $qty = $_GET["qty"];
    $cid = $_GET["id"];

    $rs=Database::search("SELECT * FROM `cart` where `id` ='$cid' ");
    $data= $rs->fetch_assoc();
    $id=$data["product_id"];
    $rs2=Database::search("SELECT * FROM `product` where `id` ='$id' ");
$data2= $rs2->fetch_assoc();

if($data2['qty'] > $qty){

    Database::iud("UPDATE `cart` SET `qty`='".$qty."' WHERE `id`='".$cid."'");
    echo ("Updated");
}else{

    echo("Number of items is not available");
}



}else{
    echo ("Something went wrong.");
}

?>