<?php
$clr = $_POST['e'];
if ($clr==1){
    setcookie('color','2', time() + 365 * 24 * 60 * 60);
    echo("black");
}else{
    setcookie('color','1', time() + 365 * 24 * 60 * 60);
    echo("white");
}


?>