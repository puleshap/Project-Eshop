<?php
include "connection.php";
session_start();
if (isset($_SESSION["au"])) {
    $data = $_SESSION["au"];
    $mail = $data["email"];

    if (isset($_POST["b"]) && isset($_POST["n"])) {


        $pw = $_POST["p"];
        $brand = $_POST["b"];
        $name = $_POST["n"];

        $admin_rs = Database::search("SELECT * FROM `admin` WHERE `email`='" . $mail . "' AND `password`='" . $pw . "'");
        $admin_num = $admin_rs->num_rows;

        if ($admin_num == 1) {
            $rs = Database::search("SELECT * FROM `model` WHERE `model_name`='" . $name . "' ");
            $num = $rs->num_rows;

            if ($num == 1) {
                echo ("Model Already Exists");
            } else {
                Database::iud("INSERT INTO `Model`(`model_name`) VALUES ('" . $name . "')");

                $rs2 = Database::search("SELECT * FROM `model` WHERE `model_name`='" . $name . "' ");
                $rs2_d = $rs2->fetch_assoc();
                $id = $rs2_d['id'];
                Database::iud("INSERT INTO `brand_has_model`(`brand_id`,`model_id` ) VALUES ('" . $brand . "','" . $id . "')");
                echo("success");
                
            }
        } else {
            echo ("Invalid password.");
        }
    } else {
        echo ("Try again later.");
    }
} else {
    echo ("Login failed.");
}
