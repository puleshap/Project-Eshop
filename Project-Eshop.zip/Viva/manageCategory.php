<?php

require "connection.php";

?>

<link rel="stylesheet" href="bootstrap.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="style.css" />
<link rel="stylesheet" href="styles/Admin_User_Panel.css" />
<div class="col-12 bg-dark text-center">
        <label class="form-label text-primary fw-bold fs-1">C a t e g o r y   &nbsp; &nbsp; M a n a g e m e n t &nbsp; &nbsp; P a n e l</label>
</div>
<div class="container">
<br>  
    <div class="search-bar">

        <input type="text" id="searchUsers" placeholder="Search Category" class=" rounded rounded-3">
        <button id="searchButton " class=" rounded rounded-3 border border-3" onclick="SearchCatogryrPanel();">🔍</button>

        <button class="btn btn-info col-3 col-lg-3 rounded border " style="margin-left: 40px; font-weight: bold;" onclick="Modalview();"> Add New Category ➕</button>

    </div>
    <br>
    <div class="table-wrapper">
        <table id="userTable">
            <thead>
                <tr>
                    <th class="bg-secondary fw-light text-center">ID</th>
                    <th class="bg-secondary fw-light text-center">Name</th>
                    <th class="bg-secondary fw-light text-center" style="max-width: 20px;">Number or related brands</th>

                </tr>
            </thead>
            <tbody id="tbody">
                <?php

                $query = "SELECT * FROM category";
                $pageno;

                if (isset($_GET["page"])) {
                    $pageno = $_GET["page"];
                } else {
                    $pageno = 1;
                }

                $user_rs = Database::search($query);
                $user_num = $user_rs->num_rows;

                $selected_rs = Database::search($query);

                $selected_num = $selected_rs->num_rows;

                for ($x = 0; $x < $selected_num; $x++) {
                    $selected_data = $selected_rs->fetch_assoc();
                    $id = $selected_data["id"];
                    $count_rs = Database::search("SELECT COUNT(`category_id`) AS `value_occurence` FROM `brand` 
                                WHERE `category_id` ='$id'");
                    $count_data = $count_rs->fetch_assoc();

                ?>

                    <tr>
                        <td  class="text-center"><?php echo ($selected_data["id"]); ?></td>
                        <td  class="text-center"><?php echo $selected_data["category_name"]; ?></td>


                        <td class="text-center"><?php echo $count_data["value_occurence"]; ?></td>


                    </tr>

                <?php

                }
                ?>

            </tbody>
        </table>
    </div>
</div>
<div class="modal" tabindex="-1" id="userMsgModal">
    <div class="modal-dialog">
        <div class="modal-content bg-dark">
            <div class="modal-header">
                <h5 class="modal-title">Add new Category</h5>
                <button type="button" class="btn-close bg-light" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <div class="row g-3">

                    <div class="col-12 mt-2">
                        <div class="row">

                        </div>
                    </div>

                    <div class="col-12">
                        <label class="form-label">Input Category Name :</label>
                        <input type="text" class="form-control text-white" style="background-color:#002d5b;" id="cat" />
                    </div>
                    <div class="col-12">
                        <label class="form-label">Enter your password :</label>
                        <input type="text" class="form-control text-white" style="background-color:#002d5b;" id="password" />
                    </div>

                </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-outline-success" onclick="AddCategory();">Create Category</button>
            </div>
        </div>
    </div>
</div>
</div>

<script src="bootstrap.bundle.js"></script>
<script src="script.js"></script>
<script src="AdminScript.js"></script>