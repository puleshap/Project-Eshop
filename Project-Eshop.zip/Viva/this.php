<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>



    <form action="loginaction.php">
        <table>
            <tr>
                <td> <Span>username :</Span> <input type="text"  name="U"/></td>
            </tr>

            <tr>
                <td> <Span>password :</Span> <input type="password"  name="P" /></td>
            </tr>

            <tr>
                <td> <input type="submit" value="Login" /></td>
            </tr>

        </table>


    </form>



</body>

</html>