<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Invoice | GamerShop</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css" />

    <link rel="icon" href="resource/logo.png" />
</head>
<?php if (isset($_COOKIE["color"])) {

?>

    <body class="mt-2 bg-dark text-white">

        <div class="container-fluid">
            <div class="row">
                <?php include "header.php";

                include "connection.php";

                if (isset($_SESSION["u"])) {
                    $umail = $_SESSION["u"]["email"];
                    $oid = $_GET["id"];

                ?>

                    <div class="col-12">
                        <hr />
                    </div>

                    <div class="col-12 ">
                        <div class="row">
                            <div class="col-2 align-content-center justify-content-center">
                            </div>
                            <div class="col-8 align-content-center justify-content-center">
                                <p style="color: darkseagreen; font-size: 30px;">Thank you for your Purchase! We hope you enjoy your product :D</p>
                            </div>
                            <div class=" col-2 btn-toolbar align-content-center justify-content-end">

                                <button class="btn btn-dark me-2" onclick="printInvoice();"><i class="bi bi-printer-fill"></i> Print</button>
                                <button class="btn btn-danger me-2" onclick="exportpdf();"><i class="bi bi-filetype-pdf"></i> Export as PDF</button>
                            </div>
                        </div>

                    </div>

                    <div class="col-12 ">
                        <hr />
                    </div>
                    <div class="page-break"></div>

                    <div class="col-12" id="page">
                        <div class="row">
                            <div class="col-lg-2 col-6 " style="background-color:#002d5b; ">
                                <div class="ms-5 invoiceHeaderImage"></div>
                            </div>
                            <div class="col-lg-2 col-6" style="background-color:#002d5b;">
                                <div class="row">
                                    <div class="col-12 text-primary text-decoration-underline">
                                        <h2>GamerShop</h2>
                                    </div>
                                    <div class="col-12 fw-bold ">
                                        <span>45 Galle Road, Colombo 03, Sri Lanka.</span><br />
                                        <span>+94112 555448</span><br />
                                        <span>GamerShop@gmail.com</span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-8 col-2" style="background-color:#002d5b;">

                            </div>





                            <div class="col-12">
                                <hr class="border border-1 border-primary" />
                            </div>

                            <div class="col-12 mb-4">
                                <div class="row">

                                    <?php

                                    $address_rs = Database::search("SELECT * FROM `user_has_address` WHERE `user_email`='" . $umail . "'");
                                    $address_data = $address_rs->fetch_assoc();

                                    ?>

                                    <div class="col-6">
                                        <h5 class="fw-bold">INVOICE TO :</h5>
                                        <h2><?php echo $_SESSION["u"]["fname"] . " " . $_SESSION["u"]["lname"]; ?></h2>
                                        <span>Line 01 : <?php echo $address_data["line1"] ?></span><br />
                                        <span>Line 02 : <?php echo $address_data["line2"] ?></span><br />
                                        <span>Email : <?php echo $umail; ?></span>
                                    </div>

                                    <?php

                                    $invoice_rs = Database::search("SELECT * FROM `invoice` WHERE `order_id`='" . $oid . "'");
                                    $invoice_data = $invoice_rs->fetch_assoc();

                                    $product_rs = Database::search("SELECT * FROM `product` WHERE `id`='" . $invoice_data["product_id"] . "'");
                                    $product_data = $product_rs->fetch_assoc();

                                    ?>

                                    <div class="col-6 text-end mt-4">
                                        <h1 class="">Order ID : <?php echo $invoice_data["order_id"]; ?></h1>
                                        <span class="text-white-50">Data & Time of Invoice : </span>&nbsp;
                                        <span class="text-white-50"><?php echo $invoice_data["date"]; ?></span>
                                    </div>

                                </div>
                            </div>

                            <div class="col-12">
                                <table class="table">
                                    <thead class="text-black">
                                        <tr class=" ">
                                            <th class="border-0"></th>
                                            <th class="border border-1 ">Product</th>

                                            <th class="text-center  border-1 border ">Quantity</th>
                                            <th class="text-end border-1 border ">Unit Price</th>
                                            <th class="text-end border-1 border ">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="text-black">
                                            <td class="border-0"></td>
                                            <td class="border">

                                                <?php



                                                ?>
                                                <span class="  fs-3 p-2"><?php echo $product_data["title"]; ?></span>
                                            </td>
                                            <td class="fw-bold fs-6 text-center border pt-3"><?php echo $invoice_data["qty"]; ?></td>
                                            <td class="fw-bold fs-6 text-end pt-3 border text-white">Rs. <?php echo $product_data["price"]; ?> .00</td>

                                            <td class="fw-bold fs-6 text-end pt-3 border text-white">Rs. <?php echo $invoice_data["total"]; ?> .00</td>
                                        </tr>
                                    </tbody>
                                    <tfoot>

                                        <?php

                                        $city_rs = Database::search("SELECT * FROM `city` WHERE `id`='" . $address_data["city_id"] . "'");
                                        $city_data = $city_rs->fetch_assoc();

                                        $delivery = 0;

                                        if ($city_data["district_id"] == 2) {
                                            $delivery = $product_data["delivery_fee_colombo"];
                                        } else {
                                            $delivery = $product_data["delivery_fee_other"];
                                        }

                                        $t = $invoice_data["total"];
                                        $g = $t - $delivery;

                                        ?>

                                        <tr>
                                            <td colspan="3" class="border-0"></td>
                                            <td class="fs-5 text-end text-white-50 border border-secondary fw-bold">SUBTOTAL</td>
                                            <td class="text-end text-white-50 border border-secondary">Rs. <?php echo $g; ?> .00</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="border-0"></td>
                                            <td class="fs-5 text-end fw-bold  text-white-50 border border-secondary">Delivery Fee</td>
                                            <td class="text-end border border-secondary text-white-50">Rs. <?php echo $delivery; ?> .00</td>
                                        </tr>
                                        <tr>
                                            <td colspan="3" class="border-0"></td>
                                            <td class="fs-5 text-end fw-bold border border-2 text-white ">GRAND TOTAL</td>
                                            <td class="fs-5 text-end fw-bold border border-2  text-white">Rs. <?php echo $t; ?> .00</td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>






                        </div>
                    </div>

                    <hr>

                    <div class="offset-3 col-6 mt-3 mb-3 border-start border-end border-top border-bottom border-2 border-warning rounded" style="background-color:#002d5b;">
                        <div class="row">
                            <div class="col-12 mt-3 mb-3">
                                <label class="form-label fs-5 text-white fw-bold">Keep in Mind : </label>
                                <br />
                                <label class="form-label fs-6 text-white">Contact Admins immediately if the sellers cannot be contacted or if the product is not supplied.</label>
                            </div>
                        </div>
                    </div>
                <?php
                }

                ?>

                <?php include "footer.php"; ?>
            </div>
        </div>
        <script src="html2pdf.bundle.min.js"></script>
        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>


    </body>

<?php
} ?>

<style>
    #page {
        width: 100%;
        color: black;
    }

    @media print {
        .page-break {
            page-break-before: always;
        }
    }
</style>

</html>