<?php
include "connection.php";
session_start();
if (isset($_SESSION["au"])) {
    $data = $_SESSION["au"];
    $mail = $data["email"];

    if (isset($_POST["t"]) && isset($_POST["c"])) {


        $pw = $_POST["c"];

        $cname = $_POST["t"];

        $admin_rs = Database::search("SELECT * FROM `admin` WHERE `email`='" . $mail . "' AND `password`='" . $pw . "'");
        $admin_num = $admin_rs->num_rows;

        if ($admin_num == 1) {
            $rs = Database::search("SELECT * FROM `category` WHERE `category_name`='" . $cname . "' ");
            $num = $rs->num_rows;

            if ($num == 1) {
                echo ("Category Already Exists");
            } else {
                Database::iud("INSERT INTO `category`(`category_name`,`status`) VALUES ('" . $cname . "','1')");
                echo ("success");
            }
        } else {
            echo ("Invalid password.");
        }
    } else {
        echo ("Try again later.");
    }
} else {
    echo ("Login failed.");
}
