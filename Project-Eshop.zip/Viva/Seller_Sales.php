<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Purchasing History | GamerShop</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="styles/Admin_User_Panel.css" />

    <link rel="icon" href="resource/logo.png" />
</head>


<body style="  background: linear-gradient(to bottom, #002d5b, #000000);color: #ffffff;">

    <div class="container-fluid">
        <div class="row">

            <?php include "header.php";

            include "connection.php";

            if (isset($_SESSION["u"])) {
                $mail = $_SESSION["u"]["email"];

                $invoice_rs = Database::search("SELECT * FROM `sales` WHERE `seller`='" . $mail . "' AND status ='1'");
                $invoice_num = $invoice_rs->num_rows;

            ?>
            <hr>

                <div class="col-12 text-center mb-3">
                    <span class="fs-1 fw-bold text-info"> Product Sales</span>
                </div>
                <ul class="nav nav-tabs bg-black" id="myTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">New Sales</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Completed Sales</button>
                    </li>
                </ul>
                <div class="tab-content" id="myTabContent">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <?php

                        if ($invoice_num == 0) {
                        ?>
                            <!-- empty view -->
                            <div class="col-12 text-center " style="height: 100px;">
                                <span class="fs-1 fw-bold text-white-50 d-block" style="margin-top: 200px;">
                                    No sales yet...
                                </span>
                            </div>
                            <!-- empty view -->
                        <?php
                        } else {
                        ?>
                            <!-- Have Product -->
                            <div class="col-12 container transaction-history">
                                <br>
                                <h2 class="text-center">New Sales to Send Out</h2>
                                <br>
                                <div class="table-responsive table-wrapper">
                                    <table class="table table-bordered ">
                                        <thead class="text-white">
                                            <tr class="text-white bg-dark">
                                                <th class=" bg-dark">Order ID</th>
                                                <th>Item</th>
                                                <th>Transaction Time</th>
                                                <th>Buyer</th>
                                                <th>Contact</th>
                                                <th>Buyer Address</th>
                                                <th>Number of Items</th>
                                                <th>Total</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $rs1 = Database::search("SELECT * FROM `sales`
                                                             INNER JOIN user ON buyer=user.email 
                                                            INNER JOIN user_has_address ON buyer=user.email
                                                            WHERE `buyer`='$mail' AND `status`='1'");
                                            $num = $rs1->num_rows;
                                            for ($x = 0; $x < $num; $x++) {
                                                $data1 = $rs1->fetch_assoc();
                                                $id = $data1['order_id'];

                                                $rs = Database::search("SELECT * FROM `invoice` WHERE `order_id`='$id'");
                                                $data = $rs->fetch_assoc();

                                                $details_rs = Database::search("SELECT * FROM `product` INNER JOIN `product_image` ON 
                                                         product.id=product_image.product_id INNER JOIN `user` ON product.user_email=user.email 
                                      WHERE `id`='" . $data["product_id"] . "'");

                                                $product_data = $details_rs->fetch_assoc();
                                            ?>
                                                <tr class="text-white">
                                                    <td class=""><?php echo ($id) ?></td>
                                                    <td class="">
                                                        <span><?php echo ($product_data['title']) ?></span>
                                                    </td>
                                                    <td class="text-danger"><?php echo ($data['date']) ?></td>
                                                    <td class="text-center"><?php echo $data1["fname"] . " " . $data1["lname"]; ?></td>
                                                    <td class=""><?php echo $data1["mobile"] ?></td>
                                                    <td class="">Address 01 : <?php echo $data1["line1"] ?> <br>Address 02 : <?php echo $data1["line2"] ?></td>
                                                    <td class="text-center"><?php echo ($data['qty']) ?></td>
                                                    <td>Rs.<?php echo ($data['total']) ?></td>
                                                    <td>
                                                        <button class="btn btn-primary" onclick="aceptsale('<?php echo $id ?>');">Completed</button>
                                                        <a href='<?php echo "invoice.php?id=" . ($id); ?>' class="btn btn-success">View Invoice</a>
                                                    </td>
                                                </tr>
                                            <?php
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>



                            <!-- Have Product -->
                    <?php
                        }
                    }

                    ?>
                    </div>
                </div>
                <div class="tab-pane fade hidden" id="profile" role="tabpanel" aria-labelledby="home-tab">
                    <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                        <br>
                        <?php
                        $invoice_rs = Database::search("SELECT * FROM `sales` WHERE `seller`='" . $mail . " ' AND status ='2'");
                        $invoice_num = $invoice_rs->num_rows;
                        if ($invoice_num == 0) {
                        ?>
                            <!-- empty view -->
                            <div class="col-12 text-center" style="height: 100px;">
                                <span class="fs-1 fw-bold text-white-50 d-block" style="margin-top: 100px;">
                                    No Sales Completed yet...
                                </span>
                            </div>
                            <!-- empty view -->
                        <?php
                        } else {
                        ?>
                            <!-- Have Product -->
                            <div class="container transaction-history mb-5">
                                <h2 class="text-center">Completed Sales</h2>
                                <div class="table-responsive table-wrapper" style="max-height: 430px;">
                                    <table class="table table-bordered ">
                                        <thead>
                                            <tr class="text-white bg-dark">
                                                <th class="text-white bg-dark">Order ID</th>
                                                <th>Item</th>
                                                <th>Transaction Time</th>
                                                <th>Buyer</th>
                                                <th>Contact</th>
                                                <th>Buyer Address</th>
                                                <th>Number of Items</th>
                                                <th>Total</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $rs1 = Database::search("SELECT * FROM `sales`
                                     INNER JOIN user ON buyer=user.email 
                                     INNER JOIN user_has_address ON buyer=user.email
                                     WHERE `seller`='$mail' AND `status`='2'");
                                            $num = $rs1->num_rows;
                                            for ($x = 0; $x < $num; $x++) {
                                                $data1 = $rs1->fetch_assoc();
                                                $id = $data1['order_id'];

                                                $rs = Database::search("SELECT * FROM `invoice` WHERE `order_id`='$id'");
                                                $data = $rs->fetch_assoc();

                                                $details_rs = Database::search("SELECT * FROM `product` INNER JOIN `product_image` ON 
                             product.id=product_image.product_id INNER JOIN `user` ON product.user_email=user.email 
                                              WHERE `id`='" . $data["product_id"] . "'");

                                                $product_data = $details_rs->fetch_assoc();
                                            ?>
                                                <tr class="text-white">
                                                    <td><?php echo ($id) ?></td>
                                                    <td>
                                                         <?php echo ($product_data['title']) ?>
                                                    </td>
                                                    <td class="text-danger"><?php echo ($data['date']) ?></td>
                                                    <td class="text-center"><?php echo $data1["fname"] . " " . $data1["lname"]; ?></td>
                                                    <td><?php echo $data1["mobile"] ?></td>
                                                    <td>
                                                        Address 01: <?php echo $data1["line1"] ?><br>
                                                        Address 02: <?php echo $data1["line2"] ?>
                                                    </td>
                                                    <td><?php echo ($data['qty']) ?></td>
                                                    <td>Rs.<?php echo ($data['total']) ?></td>
                                                </tr>
                                            <?php
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- Have Product -->
                        <?php
                        }
                        ?>
                    </div>
                </div>

                <style>

                </style>






        </div>

    </div>
    <?php include "footer.php"; ?>
    <script src="bootstrap.bundle.js"></script>
    <script src="script.js"></script>
</body>


<style>
    .table-wrapper {
        overflow-y: auto;
        border: 1px solid #ddd;
    }

    .table th,
    .table td {
        white-space: nowrap;
    }
</style>

</html>