function ShowPanel(x) {

    var panel = document.getElementById("ShowPanel");



    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;

            panel.innerHTML = response;

        }
    }

    request.open("GET", "ShowPanel.php?num=" + x, true);
    request.send();
}

function AdminShowUserPanel() {

    var panel = document.getElementById("ShowPanel");

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;

            panel.innerHTML = response;

        }
    }

    request.open("GET", "manageusers.php?", true);
    request.send();

}
function SearchUserPanel() {
    var x = document.getElementById("searchUsers").value;
    var panel = document.getElementById("tbody");
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;
            panel.innerHTML = response;
        }
    }
    request.open("GET", "Admin_User_Search_Panel.php?num=" + x, true);
    request.send();
}
function AdminShowBrandPanel() {
    var panel = document.getElementById("ShowPanel");
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;
          panel.innerHTML = response;
        }
    }
    request.open("GET", "managebrands.php?", true);
    request.send();
}
function SearchBrandPanel() {
    var x = document.getElementById("searchUsers").value;
    var panel = document.getElementById("tbody");
    var request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;
            panel.innerHTML = response;
        }
    }
    request.open("GET", "Admin_Brand_Search_Panel.php?num=" + x, true);
    request.send();
}
var mm;
function Modalview() {
    var m = document.getElementById("userMsgModal");
    mm = new bootstrap.Modal(m);
    mm.show();
}
function AddBrand() {
    var id = document.getElementById('vcode').value;

    var cat = document.getElementById('categ').value;

    var pw = document.getElementById('password').value;

    if (id == "") {

        alert("Do Not Keep Name Empty");
    } else {
        if (pw == "") {

            alert("Do Not Keep Password Empty");
        } else {
            var form = new FormData();
            form.append("t", id);
            form.append("c", cat);
            form.append("p", pw);


            var request = new XMLHttpRequest();

            request.onreadystatechange = function () {
                if (request.status == 200 & request.readyState == 4) {
                    var response = request.responseText;
                    if (response == "success") {
                        mm.hide();

                        AdminShowBrandPanel();
                    } else {
                        alert(response);
                    }

                }
            }

            request.open("POST", "saveBrandProcess.php", true);
            request.send(form);
        }
    }
}


function AdminShowCategoryPanel() {

    var panel = document.getElementById("ShowPanel");

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;

            panel.innerHTML = response;

        }
    }

    request.open("GET", "managecategory.php?", true);
    request.send();

}

function SearchCatogryrPanel() {
    var x = document.getElementById("searchUsers").value;
    var panel = document.getElementById("tbody");



    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;

            panel.innerHTML = response;

        }
    }

    request.open("GET", "Admin_Category_Search_Panel.php?n=" + x, true);
    request.send();
}

function AddCategory() {

    var cat = document.getElementById('cat').value;

    var pw = document.getElementById('password').value;

    if (cat == "") {

        alert("Please enter Category Name");
    }
    if (pw == "") {
        alert("Please enter Password ");
    }

    if (cat !== "" && pw !== "") {
        var form = new FormData();
        form.append("t", cat);
        form.append("c", pw);


        var request = new XMLHttpRequest();

        request.onreadystatechange = function () {
            if (request.status == 200 & request.readyState == 4) {
                var response = request.responseText;
                if (response == "success") {
                    mm.hide();
                    alert("Category Created Successfully");

                    AdminShowCategoryPanel();
                } else {
                    alert(response);
                }

            }
        }

        request.open("POST", "saveCategoryProcess.php", true);
        request.send(form);
    }
}


function AdminShowModelPanel() {

    var panel = document.getElementById("ShowPanel");
    var bar = document.getElementById("d-bar");
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;

            panel.innerHTML = response;


        }
    }

    request.open("GET", "managemodels.php?", true);
    request.send();

}

function SearchModelPanel() {
    var x = document.getElementById("searchUsers").value;
    var panel = document.getElementById("tbody");




    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;

            panel.innerHTML = response;


        }
    }

    request.open("GET", "Admin_Model_Search_Panel.php?num=" + x, true);
    request.send();
}



function AddModel() {

    var brand = document.getElementById('brand').value;
    var nm = document.getElementById('nm').value;

    var pw = document.getElementById('pw').value;
    if (brand == 0) {

        alert("Please Select a Brand");
    }
    if (nm == "") {

        alert("Please enter Model Name");
    }
    if (pw == "") {
        alert("Please enter Password ");
    }

    if (nm !== "" && pw !== "" && brand !== 0) {
        var form = new FormData();
        form.append("b", brand);
        form.append("n", nm);
        form.append("p", pw);


        var request = new XMLHttpRequest();

        request.onreadystatechange = function () {
            if (request.status == 200 & request.readyState == 4) {
                var response = request.responseText;
                if (response == "success") {
                    mm.hide();
                    alert("Model Created Successfully");

                    AdminShowModelPanel();
                } else {
                    alert(response);
                }

            }
        }

        request.open("POST", "saveModelProcess.php", true);
        request.send(form);
    }
}



function AdminShowProductPanel() {

    var panel = document.getElementById("ShowPanel");
    var bar = document.getElementById("d-bar");
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;

            panel.innerHTML = response;


        }
    }

    request.open("GET", "manageProduct.php?", true);
    request.send();
}


function SearchMProductPanel() {
    var x = document.getElementById("searchUsers").value;
    var panel = document.getElementById("tbody");




    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;

            panel.innerHTML = response;


        }
    }

    request.open("GET", "Admin_Product_Search_Panel.php?num=" + x, true);
    request.send();
}

var mm;

function ProductModalview(ct, br, md, count) {


    var m = document.getElementById("userMsgModal");
    document.getElementById("ct").innerHTML = ("Product Category : " + ct);
    document.getElementById("br").innerHTML = ("Product Brand : " + br);
    document.getElementById("md").innerHTML = ("Product Model : " + md);
    document.getElementById("cnt").innerHTML = ("Number of Items Sold : " + count);

    mm = new bootstrap.Modal(m);
    mm.show();
}

function AdminShowReportPanel() {

    var panel = document.getElementById("ShowPanel");

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;

            panel.innerHTML = response;


        }
    }

    request.open("GET", "Admin_Reports.php?", true);
    request.send();
}




function readreport(id) {

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;

            if (response == "success") {
                AdminShowReportPanel();
            }
        }
    }
    request.open("GET", "AdminViewReportProcess.php?e=" + id, true);
    request.send();
}



function AdminShowSalePanel() {

    var panel = document.getElementById("ShowPanel");
    var bar = document.getElementById("d-bar");
    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;

            panel.innerHTML = response;


        }
    }

    request.open("GET", "manageProduct.php?", true);
    request.send();
}


function SearchSalePanel() {
    var x = document.getElementById("searchUsers").value;
    var panel = document.getElementById("tbody");




    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;

            panel.innerHTML = response;


        }
    }

    request.open("GET", "Admin_Product_Search_Panel.php?num=" + x, true);
    request.send();
}

var mm;

function ProductModalview(ct, br, md, count) {


    var m = document.getElementById("userMsgModal");
    document.getElementById("ct").innerHTML = ("Product Category : " + ct);
    document.getElementById("br").innerHTML = ("Product Brand : " + br);
    document.getElementById("md").innerHTML = ("Product Model : " + md);
    document.getElementById("cnt").innerHTML = ("Number of Items Sold : " + count);

    mm = new bootstrap.Modal(m);
    mm.show();
}


var loadingOverlay1 = document.getElementById('loadingOverlay');


function showLoading2() {
    loadingOverlay1.style.display = 'flex';
}

// Function to hide the loading screen (example after 3 seconds)
function hideLoading2() {
    loadingOverlay1.style.display = 'none';
}

// Event listener for button click
function showup() {
 showLoading2();
    var email = document.getElementById("e");

    var form = new FormData();
    form.append("e", email.value);

    var request = new XMLHttpRequest();

    request.onreadystatechange = function () {
        if (request.status == 200 & request.readyState == 4) {
            var response = request.responseText;
            if (response == "Success") {
                hideLoading2(); 
                alert("Please take a look at your email to find the VERIFICATION CODE.");
                var adminVerificationModal = document.getElementById("verificationModal");
                av = new bootstrap.Modal(adminVerificationModal);
                av.show();
            } else {
                alert(response);
                hideLoading2();
            }

        }
    }

    request.open("POST", "adminVerificationProcess.php", true);
    request.send(form);


}