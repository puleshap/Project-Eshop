<?php

session_start();
include "connection.php";

if (isset($_SESSION["au"])) {

?>

    <!DOCTYPE html>
    <html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Admin Panel | GamerShop</title>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <link rel="stylesheet" href="bootstrap.css" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
        <link rel="stylesheet" href="style.css" />

        <link rel="icon" href="resource/logo.png" />
    </head>

    <body style="  background-color:#002d5b   ">

        <div class="container-fluid over">
            <div class="row">

                <div class="col-12 col-lg-2">
                    <div class="row">
                        <div class="col-12 align-items-start bg-dark vh-100">
                            <div class="row g-1 text-center">
                                <?php
                                $rs = Database::search("SELECT * FROM `reports` WHERE `status` ='1'");
                                $rs_num = $rs->num_rows;

                                ?>
                                <div class="col-12 mt-5">
                                    <h4 class="text-white"><?php echo $_SESSION["au"]["fname"] . " " . $_SESSION["au"]["lname"]; ?></h4>
                                    <hr class="border border-1 border-white" />
                                </div>
                                <div class="nav flex-column nav-pills me-3 mt-3" role="tablist" aria-orientation="vertical">
                                    <nav class="nav flex-column">
                                        <a class="nav-link active mb-4 " aria-current="page" href="adminPanel.php"><label class="fw-bold"> Dashboard</label></a>

                                        <a class=" mb-4 btn btn-outline-primary" href="adminPanel2.php"> <label class="fw-bold">Management</label< /a>
                                                <a class=" btn btn-outline-primary" href="adminPanel3.php"><label class="fw-bold"> Reports
                                                        <?php if ($rs_num > 0) { ?>
                                                            🛑
                                                        <?php
                                                        }  ?>
                                                    </label> </a>

                                    </nav>
                                </div>
                                <div class="col-12 mt-5 ">
                                    <hr class="border border-1 border-white" />
                                    <button class="btn btn-outline-danger" onclick="signout();">LogOut</button>
                                    <hr class="border border-1 border-white" />
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-12 col-lg-10">
                    <div class="row">

                        <div class="text-white fw-bold mb-1 mt-3">
                            <h2 class="fw-bold">Gamer Shop Admin Dashboard</h2>
                        </div>
                        <div class="col-12">
                            <hr />
                        </div>
                        <div class="col-12 bg-dark" id="d-bar">
                            <div class="row">

                                <div class="col-12 col-lg-12  my-3">

                                    <button class="btn btn-outline-success text-white col-2 rounded border border-1 border  fs-5" onclick="ShowPanel(1);"> Daily</button>
                                    <label class=" col-1"></label>

                                    <button class="btn btn-outline-success text-white col-2  rounded border border-1 border  fs-5" onclick="ShowPanel(2);"> Monthly</button>
                                    <label class=" col-1"></label>
                                    <button class="btn btn-outline-success text-white col-2  rounded border border-1 border  fs-5" onclick="ShowPanel(3);"> Yearly</button>
                                    <label class=" col-1"></label>
                                    <button class="btn btn-outline-success text-white col-2  rounded border border-1 border  fs-5" onclick="ShowPanel(4);"> All time</button>

                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="row g-1 mt-2" id="ShowPanel">
                                <?php
                                $month_names = [
                                    1 => 'January',
                                    2 => 'February',
                                    3 => 'March',
                                    4 => 'April',
                                    5 => 'May',
                                    6 => 'June',
                                    7 => 'July',
                                    8 => 'August',
                                    9 => 'September',
                                    10 => 'October',
                                    11 => 'November',
                                    12 => 'December'
                                ];
                                $sales_query = "SELECT  MONTH(date) AS month,  SUM(total) AS total_sales
                                FROM  invoice WHERE  YEAR(date) = YEAR(CURDATE())
                                GROUP BY  MONTH(date); ";
                                $sales_result = Database::search($sales_query);
                                $sales_data = [];
                                if ($sales_result->num_rows > 0) {
                                    while ($row = $sales_result->fetch_assoc()) {
                                        $sales_data[] = $row;
                                    }
                                }
                                $months = [];
                                $total_sales = [];

                                foreach ($sales_data as $data) {
                                    $months[] = $month_names[(int)$data['month']];;
                                    $total_sales[] = $data['total_sales'];
                                }
                                ?>
                                <div class="offset-1 offset-lg-4   col-10 col-lg-4 my-3 rounded bg-body">

                                    <div class="row g-1">


                                        <canvas id="salesChart" width="40" height="20"></canvas>
                                        <script>
                                            var ctx = document.getElementById('salesChart').getContext('2d');
                                            var salesChart = new Chart(ctx, {
                                                type: 'bar',
                                                data: {
                                                    labels: <?php echo json_encode($months); ?>,
                                                    datasets: [{
                                                        label: 'Profits per month this Year : Rs.',
                                                        data: <?php echo json_encode($total_sales); ?>,

                                                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                                                        borderColor: 'rgba(54, 162, 235, 1)',
                                                        borderWidth: 1.5
                                                    }]
                                                },
                                                options: {
                                                    scales: {
                                                        y: {
                                                            beginAtZero: true
                                                        }
                                                    }
                                                }
                                            });
                                        </script>




                                    </div>

                                </div>

                                <?php



                            
                                $user_query = "SELECT  MONTH(joined_date) AS month,  COUNT(email) AS users
                                FROM  user WHERE  YEAR(joined_date) = YEAR(CURDATE())
                                GROUP BY  MONTH(joined_date); ";
                                $user_result = Database::search($user_query);


                                $user_data = [];

                                if ($user_result->num_rows > 0) {
                                    while ($row = $user_result->fetch_assoc()) {
                                        $user_data[] = $row;
                                    }
                                }

                             
                                $months = [];
                                $users = [];

                         

                                foreach ($user_data as $data) {
                                    $months[] = $month_names[(int)$data['month']];
                                    $users[] = $data['users'];
                                }
                                ?>
                                <div class="offset-1 offset-lg-4  col-10 col-lg-4 my-3 rounded bg-body">
                                    <div class="row ">

                                        <canvas id="userchart" width="40" height="20"></canvas>
                                        <script>
                                            userchart
                                            var ctx = document.getElementById('userchart').getContext('2d');
                                            var userchart = new Chart(ctx, {
                                                type: 'bar',
                                                data: {
                                                    labels: <?php echo json_encode($months); ?>,
                                                    datasets: [{
                                                        label: 'Users Joined during the months',
                                                        data: <?php echo json_encode($users); ?>,
                                                        backgroundColor: 'rgba(54, 162, 235, 0.2)',
                                                        borderColor: 'rgba(54, 162, 235, 1)',
                                                        borderWidth: 1
                                                    }]
                                                },
                                                options: {
                                                    scales: {
                                                        y: {
                                                            beginAtZero: true
                                                        }
                                                    }
                                                }
                                            });
                                        </script>




                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="col-12">
                            <hr />
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <script src="bootstrap.bundle.js"></script>
        <script src="script.js"></script>
        <script src="AdminScript.js"></script>
    </body>

    </html>

<?php

} else {
    echo ("You are not a valid user.");
}

?>