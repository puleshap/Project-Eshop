<?php
session_start();
include "connection.php";

if (isset($_SESSION["u"])) {
    $umail = $_SESSION["u"]["email"];

    $shipping = $_POST["shipping"];
    $value = $_POST["value"];
    $number = $_POST["number"];
    $total = $_POST["total"];
    $itemNamesJSON = $_POST['itemNames'];
    $itemPriceJSON = $_POST['itemPrice'];
    $itemNames1 = $_POST['itemNames1'];
    $itemwtysJSON = $_POST['itemqty']; // JSON string

    // Decode JSON data
    $order_id = uniqid();
    $itemNames = json_decode($itemNamesJSON, true); // true parameter to decode as associative array
    $itemwtys = json_decode($itemwtysJSON, true); // true parameter to decode as associative array
    $itemwprice = json_decode($itemPriceJSON, true);
    // Check if both arrays have the same length
    if (count($itemNames) != count($itemwtys)) {
        echo ('Item names and quantities do not match in length');
    } else {

        $d = new DateTime();
        $tz = new DateTimeZone("Asia/Colombo");
        $d->setTimezone($tz);
        $date = $d->format("Y-m-d H:i:s");
    //     Database::iud("INSERT INTO `invoice_multiple`(`order_id`,`product_titles`,`qty`,`total`,`shipping`,`user_email`,`date`) VALUES ('" . $order_id . "','" . $itemNames1 . "','$number','$value','$shipping','$umail','$date')");
    // }
    }
    for ($i = 0; $i < count($itemNames); $i++) {
        $itemName = $itemNames[$i];
        $itemwty = $itemwtys[$i];
        $itemPrice = $itemwprice[$i];
        Database::iud("INSERT INTO `cartinvoice`(`order_id`,`title`,`price`,`qty`) VALUES ('" . $order_id . "','" . $itemName . "','$itemPrice','" . $itemwty . "')");
    }


    $array;







    $city_rs = Database::search("SELECT * FROM `user_has_address` WHERE `user_email`='" . $umail . "'");
    $city_num = $city_rs->num_rows;

    if ($city_num == 1) {

        $city_data = $city_rs->fetch_assoc();

        $city_id = $city_data["city_id"];
        $address = $city_data["line1"] . ", " . $city_data["line2"];

        $district_rs = Database::search("SELECT * FROM `city` WHERE `id`='" . $city_id . "'");
        $district_data = $district_rs->fetch_assoc();

        $district_id = $district_data["district_id"];





        $fname = $_SESSION["u"]["fname"];
        $lname = $_SESSION["u"]["lname"];
        $mobile = $_SESSION["u"]["mobile"];
        $uaddress = $address;
        $city = $district_data["name"];

        $merchant_id = "1222039";
        $merchant_secret = "NDEyNjI2NjAwMTMzMTYyMDQ1NTE2NTYxNTc5MDgyMzE4MzQzNjc3";
        $currency = "LKR";

        $hash = strtoupper(
            md5(
                $merchant_id .
                    $order_id .
                    number_format($total, 2, '.', '') .
                    $currency .
                    strtoupper(md5($merchant_secret))
            )
        );
        $array["shipping"] = $shipping;
        $array["id"] = $order_id;
        $array["item"] = $itemNames1;
        $array["amount"] = $total;
        $array["fname"] = $fname;
        $array["lname"] = $lname;
        $array["mobile"] = $mobile;
        $array["address"] = $uaddress;
        $array["city"] = $city;
        $array["umail"] = $umail;
        $array["mid"] = $merchant_id;
        $array["msecret"] = $merchant_secret;
        $array["currency"] = $currency;
        $array["hash"] = $hash;

        echo json_encode($array);
    } else {
        echo ("2");
    }
} else {
    echo ("1");
}
