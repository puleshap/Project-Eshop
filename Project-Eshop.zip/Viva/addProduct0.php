<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="dashboard">
        <div class="sidebar">
            <h2>Company Name</h2>
            <ul>
                <li class="active">Dashboard</li>
                <li>Categories</li>
                <li>Brands</li>
                <li>Products</li>
                <li>Sales</li>
                <li>Customers</li>
                <li>Suppliers</li>
                <li class="logout">LogOut</li>
            </ul>
        </div>
        <div class="main-content">
            <div class="header">
                <span>Daily</span>
                <span>Monthly</span>
                <span>Yearly</span>
                <span>All Time</span>
                <img src="logo.png" alt="Logo" class="logo">
            </div>
            <div class="stats">
                <div class="stat-box">
                    <h3>Number of Sales</h3>
                    <p>235</p>
                </div>
                <div class="stat-box">
                    <h3>New Joined Customers</h3>
                    <p>10</p>
                </div>
                <div class="stat-box">
                    <h3>Most Sold Product</h3>
                    <p>Product Name</p>
                </div>
                <div class="stat-box">
                    <h3>Most Sold Product Category</h3>
                    <p>Category Name</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<style>body {
    font-family: Arial, sans-serif;
    background-color: #dcdcdc;
    margin: 0;
    padding: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.dashboard {
    display: flex;
    width: 90%;
    max-width: 1200px;
    background-color: #888;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.sidebar {
    width: 20%;
    background-color: #666;
    padding: 20px;
    box-sizing: border-box;
    color: white;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.sidebar h2 {
    text-align: center;
    margin-bottom: 30px;
}

.sidebar ul {
    list-style: none;
    padding: 0;
}

.sidebar li {
    padding: 10px;
    background-color: #bbb;
    margin-bottom: 10px;
    text-align: center;
    cursor: pointer;
}

.sidebar li.active {
    background-color: #1E90FF;
    color: white;
}

.sidebar li.logout {
    margin-top: auto;
    background-color: #f44336;
    color: white;
}

.main-content {
    width: 80%;
    padding: 20px;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
}

.header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background-color: #888;
    padding: 10px;
    border-bottom: 2px solid #444;
}

.header span {
    flex: 1;
    text-align: center;
    cursor: pointer;
}

.header span:not(:last-child) {
    border-right: 1px solid #444;
}

.logo {
    width: 50px;
    height: 50px;
    border-radius: 50%;
}

.stats {
    display: flex;
    flex-wrap: wrap;
    margin-top: 20px;
    gap: 20px;
}

.stat-box {
    flex: 1 1 calc(50% - 20px);
    background-color: #bbb;
    padding: 20px;
    box-sizing: border-box;
    text-align: center;
    border-radius: 10px;
}

.stat-box h3 {
    margin-bottom: 20px;
}

.stat-box p {
    font-size: 24px;
    margin: 0;
}
</style>