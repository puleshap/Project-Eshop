<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Messages | Gamershop</title>

    <link rel="stylesheet" href="bootstrap.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
    <link rel="stylesheet" href="style.css" />
    <link rel="stylesheet" href="styles/Admin_User_Panel.css" />

    <link rel="icon" href="resource/logo.png" />
</head>





<?php
include "connection.php";
session_start();
$mail = $_SESSION["au"]["email"];
?>
<div class="col-12 bg-dark text-center">
    <label class="form-label text-primary fw-bold fs-1">R e p o r t &nbsp; &nbsp; C h e c k i n g &nbsp; &nbsp; P a n e l</label>
</div>



<div class="col-12 ">
    <div class=" ">
        <div class="offset-lg-1 col-12 col-lg-10 ">
            <div class="bg-white">
                <div class="bg-dark">

                    <div class="col-12">

                        <?php

                        $msg_rs = Database::search("SELECT  title, reports.*,product_image.* FROM `reports` 
                                    INNER JOIN   product ON reports.product_id=product.id
                                    INNER JOIN product_image ON reports.product_id = product_image.product_id
                                    ORDER BY reports.date_time DESC");
                        $msg_num = $msg_rs->num_rows;

                        ?>

                        <!--  -->
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">New Reports</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Read Reports</button>
                            </li>
                        </ul>
                        <div class="tab-content" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <div class="message_box" id="message_box">

                                    <?php

                                    for ($x = 0; $x < $msg_num; $x++) {
                                        $msg_data = $msg_rs->fetch_assoc();
                                        $id = $msg_data["id"];
                                        $sender = $msg_data["user_email"];

                                        $user_rs = Database::search("SELECT * FROM `user` WHERE `email`='" . $sender . "'");

                                        $img_rs = Database::search("SELECT * FROM `profile_image` WHERE `user_email`='" . $sender . "'");

                                        $user_data = $user_rs->fetch_assoc();
                                        $img_data = $img_rs->fetch_assoc();

                                        if ($msg_data["status"] == 1) {
                                    ?>
                                            <br>
                                            <div class="list-group rounded-0 ">

                                                <div class="media bg-info ">
                                                    <a href='<?php echo "singleProductView.php?id=" . ($msg_data["product_id"]); ?>'> <button> 👁️</button>
                                                    </a>
                                                    <div class="media-body">
                                                        <div class="d-flex align-items-center justify-content-between mb-1">
                                                            <h6 class="mb-0 fw-bold">Reported By : <?php echo $user_data["fname"] . " " . $user_data["lname"]; ?> -- <?php echo $msg_data["user_email"]; ?></h6>
                                                            <small class="small fw-bold"><?php echo $msg_data["date_time"]; ?></small>

                                                        </div>
                                                        <p class="mb-0">Product (<?php echo $msg_data["product_id"]; ?>) Title : <?php echo $msg_data["title"]; ?></p>
                                                        <p class="mb-0">Reason for Report : <?php echo $msg_data["report_text"]; ?></p>



                                                    </div>
                                                    <button onclick="readreport(<?php echo $id ?>);"> ✅</button>
                                                </div>





                                            </div>
                                        <?php
                                        }
                                        ?>

                                    <?php

                                    }

                                    ?>
                                </div>

                            </div>
                            <?php

                            $msg_rs = Database::search("SELECT  title, reports.*,product_image.* FROM `reports` 
                              INNER JOIN   product ON reports.product_id=product.id
                                 INNER JOIN product_image ON reports.product_id = product_image.product_id
                                     ORDER BY reports.date_time DESC");
                            $msg_num = $msg_rs->num_rows;

                            ?>
                            <div class="tab-pane fade show hidden" id="profile" role="tabpanel" aria-labelledby="home-tab">
                                <div class="message_box" id="message_box">
                                    <?php

                                    for ($x = 0; $x < $msg_num; $x++) {
                                        $msg_data = $msg_rs->fetch_assoc();
                                        $id = $msg_data["id"];
                                        $sender = $msg_data["user_email"];

                                        $user_rs = Database::search("SELECT * FROM `user` WHERE `email`='" . $sender . "'");

                                        $img_rs = Database::search("SELECT * FROM `profile_image` WHERE `user_email`='" . $sender . "'");

                                        $user_data = $user_rs->fetch_assoc();
                                        $img_data = $img_rs->fetch_assoc();

                                        if ($msg_data["status"] == 2) {
                                    ?>
                                            <br>
                                            <div class="list-group rounded-0 ">

                                                <div class="media bg-info ">
                                                    <a href='<?php echo "singleProductView.php?id=" . ($msg_data["product_id"]); ?>'> <button> 👁️</button>
                                                    </a>
                                                    <div class="media-body">
                                                        <div class="d-flex align-items-center justify-content-between mb-1">
                                                            <h6 class="mb-0 fw-bold">Reported By : <?php echo $user_data["fname"] . " " . $user_data["lname"]; ?> -- <?php echo $msg_data["user_email"]; ?></h6>
                                                            <small class="small fw-bold"><?php echo $msg_data["date_time"]; ?></small>

                                                        </div>
                                                        <p class="mb-0">Product (<?php echo $msg_data["product_id"]; ?>) Title : <?php echo $msg_data["title"]; ?></p>
                                                        <p class="mb-0">Reason for Report : <?php echo $msg_data["report_text"]; ?></p>



                                                    </div>

                                                </div>





                                            </div>
                                        <?php
                                        }
                                        ?>

                                    <?php

                                    }

                                    ?>
                                </div>
                            </div>
                        </div>
                        <!--  -->
                    </div>
                </div>
            </div>
        </div>



    </div>
</div>



<script src="AdminScript.js"></script>
<script src="bootstrap.bundle.js"></script>
<script src="script.js"></script>