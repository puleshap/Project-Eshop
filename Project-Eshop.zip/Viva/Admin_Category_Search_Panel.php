<?php

require "connection.php";

$as = $_GET["n"];
?>

<link rel="stylesheet" href="bootstrap.css" />
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">
<tbody id="tbody">
    <?php

    $query = "SELECT brand.id AS brand_id, brand.*, category.*
                        FROM brand
                        INNER JOIN category ON brand.category_id = category.id AND `brand_name` LIKE '%" . $as . "%'";
    $pageno;

    if (isset($_GET["page"])) {
        $pageno = $_GET["page"];
    } else {
        $pageno = 1;
    }

    $user_rs = Database::search($query);
    $user_num = $user_rs->num_rows;

    $selected_rs = Database::search($query);

    $selected_num = $selected_rs->num_rows;
    if ($selected_num != 0) {
        for ($x = 0; $x < $selected_num; $x++) {
            $selected_data = $selected_rs->fetch_assoc();
            $id = $selected_data["id"];
            $count_rs = Database::search("SELECT COUNT(`category_id`) AS `value_occurence` FROM `brand` 
                        WHERE `category_id` ='$id'");
            $count_data = $count_rs->fetch_assoc();


    ?>

            <tr>
                <td class="text-center"><?php echo ($selected_data["id"]); ?></td>
                <td class="text-center"><?php echo $selected_data["category_name"]; ?></td>


                <td class="text-center"><?php echo $count_data["value_occurence"]; ?></td>


            </tr>
        <?php

        }
        ?>
    <?php

    } else {
        echo ("Brand Name does not exist");
    ?>

    <?php

    }
    ?>


</tbody>
</table>
</div>
</div>
<script src="bootstrap.bundle.js"></script>
<script src="script.js"></script>
</body>

</html>